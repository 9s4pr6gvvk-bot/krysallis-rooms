-- migrate-v36-developer: add is_developer role to practitioners table
-- Apply with: npx wrangler d1 execute krysallis-cms --remote --file=./migrate-v36-developer.sql

ALTER TABLE practitioners ADD COLUMN is_developer INTEGER DEFAULT 0;

UPDATE practitioners SET is_developer = 1 WHERE email = 'franksmedia23@gmail.com';
