-- migrate-v28-deals: monthly block agreements from email chain
-- Apply with: npx wrangler d1 execute krysallis-cms --remote --file=./migrate-v28-deals.sql
-- Overruns above included_hours are billed automatically at the standard £14.50/hr ad hoc rate.

-- Caroline Smith: 13h/wk x 52/12 = 56.33h/mo included. £345/mo flat fee.
INSERT INTO monthly_agreements (practitioner_id, amount_pence, included_hours, note, starts_month, active)
VALUES (
  (SELECT id FROM practitioners WHERE name='Caroline S'),
  34500, 56.33,
  'Long-standing block deal. ~13h/wk Mon/Wed/Fri. Overruns billed at £14.50/hr.',
  '2026-09', 1
);

-- Leah Pryce: 8h/wk x 52/12 = 34.67h/mo included. £275/mo flat fee.
INSERT INTO monthly_agreements (practitioner_id, amount_pence, included_hours, note, starts_month, active)
VALUES (
  (SELECT id FROM practitioners WHERE name='Leah P'),
  27500, 34.67,
  'Long-standing block deal. ~8h/wk. Overruns billed at £14.50/hr.',
  '2026-09', 1
);

-- Sarah Teece: 10.4h/wk avg x 52/12 = 45.07h/mo included. £330/mo flat fee. Confirm exact hours with Paddy.
INSERT INTO monthly_agreements (practitioner_id, amount_pence, included_hours, note, starts_month, active)
VALUES (
  (SELECT id FROM practitioners WHERE name='Sarah T'),
  33000, 45.07,
  'Long-standing block deal. £330/mo. Exact weekly hours to confirm with Paddy. Overruns billed at £14.50/hr.',
  '2026-09', 1
);

-- Zoe Martin: 5h/wk x 52/12 = 21.67h/mo included. £200/mo flat fee.
INSERT INTO monthly_agreements (practitioner_id, amount_pence, included_hours, note, starts_month, active)
VALUES (
  (SELECT id FROM practitioners WHERE name='Zoe'),
  20000, 21.67,
  'Long-standing block deal. 5h/wk Wednesday. Overruns billed at £14.50/hr.',
  '2026-09', 1
);

-- Sue Allen: 10h/wk x 52/12 = 43.33h/mo included. £265/mo flat fee.
INSERT INTO monthly_agreements (practitioner_id, amount_pence, included_hours, note, starts_month, active)
VALUES (
  (SELECT id FROM practitioners WHERE name='Sue Allen'),
  26500, 43.33,
  'Long-standing block deal. Thu 9am-3pm + Fri 12-1pm = 10h/wk. Overruns billed at £14.50/hr.',
  '2026-09', 1
);

-- Susannah Jaeger: 3h/wk x 46 weeks/12 = 11.5h/mo included. £126.50/mo flat fee.
INSERT INTO monthly_agreements (practitioner_id, amount_pence, included_hours, note, starts_month, active)
VALUES (
  (SELECT id FROM practitioners WHERE name='Susannah J'),
  12650, 11.5,
  'Harlow deal. Mon 3-6pm (3h/wk) at £11/hr, 6 weeks holiday included. Overruns billed at £14.50/hr.',
  '2026-09', 1
);

-- Sara Caswell: 4.5h/wk x 46 weeks/12 = 17.25h/mo included. £190.25/mo flat fee.
INSERT INTO monthly_agreements (practitioner_id, amount_pence, included_hours, note, starts_month, active)
VALUES (
  (SELECT id FROM practitioners WHERE name='Sara Caswell'),
  19025, 17.25,
  'Harlow deal. Tue block (4.5h) at £11/hr, 6 weeks holiday included. Overruns billed at £14.50/hr.',
  '2026-09', 1
);
