-- v62: 6-digit sign-in codes. Replaces the clickable magic link (which mail
-- privacy prefetchers and scanners were consuming) with a code the person types
-- on the branded sign-in page. Safe to run more than once.

CREATE TABLE IF NOT EXISTS auth_codes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  email      TEXT NOT NULL,
  code       TEXT NOT NULL,            -- 6 digits
  expires_at TEXT NOT NULL,
  used       INTEGER DEFAULT 0,
  attempts   INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_auth_codes_email ON auth_codes(email);
CREATE INDEX IF NOT EXISTS idx_auth_codes_expires ON auth_codes(expires_at);
