-- migrate-v43-deal-weeks: make monthly-deal allowances flex to the real number of
-- their days in each month, so a 5-occurrence month is not billed as an overrun.
-- Adds included_per_week (weekly contracted hours) and weekdays (0=Sun..6=Sat, CSV).
-- report.js uses these when present and falls back to the flat included_hours if not.

ALTER TABLE monthly_agreements ADD COLUMN included_per_week REAL DEFAULT 0;
ALTER TABLE monthly_agreements ADD COLUMN weekdays TEXT DEFAULT '';

-- Zoe Martin: 5h/wk, Wednesday
UPDATE monthly_agreements SET included_per_week=5,  weekdays='3'
  WHERE practitioner_id=(SELECT id FROM practitioners WHERE name='Zoe');
-- Sara Caswell: 4.5h/wk, Tuesday
UPDATE monthly_agreements SET included_per_week=4.5, weekdays='2'
  WHERE practitioner_id=(SELECT id FROM practitioners WHERE name='Sara Caswell');
-- Susannah Jaeger: 3h/wk, Monday
UPDATE monthly_agreements SET included_per_week=3,  weekdays='1'
  WHERE practitioner_id=(SELECT id FROM practitioners WHERE name='Susannah J');
-- Sue Allen: 10h/wk across Thursday + Friday
UPDATE monthly_agreements SET included_per_week=10, weekdays='4,5'
  WHERE practitioner_id=(SELECT id FROM practitioners WHERE name='Sue Allen');
-- Caroline Smith: 13h/wk across Monday, Wednesday, Friday
UPDATE monthly_agreements SET included_per_week=13, weekdays='1,3,5'
  WHERE practitioner_id=(SELECT id FROM practitioners WHERE name='Caroline S');
-- Leah Pryce: 8h/wk across Tuesday, Wednesday, Thursday
UPDATE monthly_agreements SET included_per_week=8,  weekdays='2,3,4'
  WHERE practitioner_id=(SELECT id FROM practitioners WHERE name='Leah P');
-- Sarah Teece: 10.4h/wk across Thursday, Friday, Saturday
UPDATE monthly_agreements SET included_per_week=10.4, weekdays='4,5,6'
  WHERE practitioner_id=(SELECT id FROM practitioners WHERE name='Sarah T');
