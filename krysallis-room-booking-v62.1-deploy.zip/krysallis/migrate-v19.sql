-- Upgrade an existing live database to v19.
-- Apply with:
--   npx wrangler d1 execute krysallis-cms --remote --file=./migrate-v19.sql

-- 1. Cancellation window moves from 48 hours to 24.
INSERT INTO app_settings (key, value) VALUES ('notice_hours', '24')
  ON CONFLICT(key) DO UPDATE SET value = '24', updated_at = datetime('now');

-- 2. Longer sessions and a longer booking horizon for repeat series.
INSERT INTO app_settings (key, value) VALUES ('max_duration_min', '480')
  ON CONFLICT(key) DO UPDATE SET value = '480', updated_at = datetime('now');
INSERT INTO app_settings (key, value) VALUES ('horizon_days', '365')
  ON CONFLICT(key) DO UPDATE SET value = '365', updated_at = datetime('now');

-- 3. Retire the shared meeting room: it is booked through Krysallis central
--    admin, not here. Soft delete keeps any historic bookings intact.
UPDATE rooms SET active = 0 WHERE lower(name) LIKE '%meeting%';

-- 4. Monthly agreements ("block deals") for the report and CSV.
CREATE TABLE IF NOT EXISTS monthly_agreements (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  practitioner_id INTEGER NOT NULL,
  amount_pence    INTEGER NOT NULL DEFAULT 0,
  included_hours  REAL    DEFAULT 0,
  note            TEXT    DEFAULT '',
  starts_month    TEXT    NOT NULL,
  ends_month      TEXT    DEFAULT NULL,
  active          INTEGER DEFAULT 1,
  created_at      TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_agree_pract ON monthly_agreements(practitioner_id);
