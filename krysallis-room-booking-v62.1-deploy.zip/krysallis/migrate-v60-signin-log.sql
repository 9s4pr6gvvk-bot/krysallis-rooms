-- v60: sign-in log. Records every step of the magic-link flow so a failed
-- sign-in can be diagnosed after the fact from the admin console.
-- Safe to run more than once.

CREATE TABLE IF NOT EXISTS auth_log (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  ts      TEXT DEFAULT (datetime('now')),
  email   TEXT,
  event   TEXT NOT NULL,
  detail  TEXT,
  ip      TEXT,
  ua      TEXT
);
CREATE INDEX IF NOT EXISTS idx_auth_log_ts ON auth_log(ts);
CREATE INDEX IF NOT EXISTS idx_auth_log_email ON auth_log(email);
