# Krysallis Room Booking

Standalone booking app for Krysallis, running at its own domain
(krysallisroombooking.co.uk). Cloudflare Pages + Pages Functions + D1.
No WordPress, no npm, no build step.

## What it does
- Practitioners sign in by one-time email link (no passwords, no 30 accounts to manage).
- Book a room with live availability; a room can never be double-booked.
- **All rooms** calendar: one week grid showing every free time across all four
  rooms at once, with the available room numbers written on each open block.
  Click a number to take that room, or click the block and choose the room on
  the confirmation panel. Individual room tabs still work as before.
- Session lengths in half hours (30 min up to 8 hours), so 1.5, 2.5, 3.5 and up are all bookable.
- Repeats: every week or every two weeks, ending after a set number of sessions
  or on a date of the booker's choosing. Every date in the pattern is checked
  before anything is saved; clashes are listed by date and the rest of the
  series can be booked around them.
- Every booking is tagged **private** (the therapist's own client, chargeable)
  or **Krysallis** (a referred client, not chargeable). The choice is
  compulsory, so dual therapists no longer confirm it by email. No client
  details are ever stored.
- 24-hour cancellation rule applied automatically. Inside the window the
  therapist can no longer remove the session and it stays chargeable; Krysallis
  admin can still cancel it, with or without the charge.
- Rates applied automatically: ad hoc £14.50/hr, block £11/hr from 4 hours.
- Monthly deals: a fixed monthly fee per therapist, optionally covering a set
  number of hours, with anything over the allowance billed on at the ad hoc
  rate. These flow straight into the monthly report and the CSV.
- Admin (Paddy): every booking, edit/move/cancel, block or restore a
  therapist's access, monthly per-practitioner report with CSV export, manage
  rooms, people, deals and the booking rules themselves.
- One-way push to a read-only Google Calendar is stubbed and ready to wire once
  access is granted (shared/gcal.js). Nothing else waits on it.

## Deploy
    npx wrangler d1 create krysallis-cms          # paste the id into wrangler.toml
    npx wrangler d1 execute krysallis-cms --remote --file=./schema.sql
    npx wrangler d1 execute krysallis-cms --remote --file=./seed.sql
    npx wrangler pages secret put SESSION_SECRET   # any long random string
    npx wrangler pages secret put RESEND_API_KEY   # optional until you want live email
    npx wrangler pages deploy public --project-name krysallisroombooking

### Upgrading an existing database to v19
    npx wrangler d1 execute krysallis-cms --remote --file=./migrate-v19.sql

That moves the notice window to 24 hours, retires the shared meeting room,
raises the maximum session length, and creates the monthly deals table. It is
safe to run more than once.

## Decisions baked in (confirm before go-live)
1. **Google Calendar is one-way** (app -> read-only calendar the building views).
   Paddy works in this app, not directly in Google Calendar. Access needed:
   Make changes to events on a calendar dedicated to room bookings.
2. **No 30 passworded logins.** Identity is by email link. Same security
   outcome, far less admin.
3. **The shared meeting room is not bookable here.** It is a whole-office space
   shared with the other tenants and goes through Krysallis central admin, so
   it is left out of the seed data and retired by the migration.
4. **Block rate rule:** any single booking of block_min_minutes (default 240 =
   4 hours) or longer earns the £11 rate, whether it is a one-off or part of a
   series. Everything shorter is £14.50. Adjust rateForBooking() in
   shared/booking-logic.js if "4 hours or more" is ever meant as a weekly total.
5. **Krysallis bookings** carry no room charge and are recorded as a tag only.
6. **Blocking beats removing.** Blocking stops sign-in immediately and keeps the
   history for reporting. Removing is refused while future bookings exist.
7. Times are stored in UTC and shown in Europe/London. Repeating series step in
   local calendar weeks, so a 10am session stays 10am across the clock changes.
8. Rates, the notice window, the block threshold and the longest session are all
   editable in the admin Settings tab; nothing needs redeploying to change them.
