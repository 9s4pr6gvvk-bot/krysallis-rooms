// One-way Google Calendar push (booking system -> Google Calendar).
// Uses a Google Service Account with RS256 JWT to get short-lived access tokens.
// Secrets needed in Cloudflare Pages (set via wrangler or dashboard):
//   GCAL_SA_EMAIL       service account client_email
//   GCAL_SA_KEY         service account private_key (full PEM string)
//   GCAL_CAL_ROOM1      calendar ID for Room 1
//   GCAL_CAL_ROOMS23    calendar ID for Rooms 2 & 3
//   GCAL_CAL_ROOM4      calendar ID for Room 4

// Map room_id to the correct calendar ID env var
function calendarId(env, roomId) {
  switch (String(roomId)) {
    case '1': return env.GCAL_CAL_ROOM1;
    case '2': return env.GCAL_CAL_ROOMS23;
    case '3': return env.GCAL_CAL_ROOMS23;
    case '4': return env.GCAL_CAL_ROOM4;
    default:  return null;
  }
}

// Build a signed JWT and exchange it for an access token
async function getAccessToken(env) {
  const email = env.GCAL_SA_EMAIL;
  const rawKey = env.GCAL_SA_KEY;
  if (!email || !rawKey) return null;

  const now = Math.floor(Date.now() / 1000);
  const claim = {
    iss: email,
    scope: 'https://www.googleapis.com/auth/calendar.events',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now,
  };

  // Import the private key
  const pemBody = rawKey.replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----/g, '').replace(/[\r\n\s]/g, '');
  const der = Uint8Array.from(atob(pemBody), c => c.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    'pkcs8', der.buffer,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false, ['sign']
  );

  // Build JWT header.payload
  const b64url = s => btoa(unescape(encodeURIComponent(JSON.stringify(s))))
    .replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
  const header = b64url({ alg: 'RS256', typ: 'JWT' });
  const payload = b64url(claim);
  const sigInput = new TextEncoder().encode(`${header}.${payload}`);
  const sigBuf = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, sigInput);
  const sig = btoa(String.fromCharCode(...new Uint8Array(sigBuf)))
    .replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
  const jwt = `${header}.${payload}.${sig}`;

  // Exchange JWT for access token
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}`,
  });
  if (!res.ok) return null;
  const data = await res.json();
  return data.access_token || null;
}

// Push a booking to the correct room calendar. Returns the gcal event id or null.
// Pass a pre-fetched token to avoid re-authenticating on every occurrence in a series.
export async function pushBooking(env, { summary, startUtc, durationMin, roomId, token: preToken }) {
  const calId = calendarId(env, roomId);
  if (!calId) return null;
  const token = preToken || await getAccessToken(env);
  if (!token) return null;

  const start = new Date(startUtc + 'Z');
  const end   = new Date(start.getTime() + durationMin * 60000);
  const body  = {
    summary,
    start: { dateTime: start.toISOString() },
    end:   { dateTime: end.toISOString() },
  };

  const res = await fetch(
    `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calId)}/events`,
    {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }
  );
  if (!res.ok) return null;
  const ev = await res.json();
  return ev.id || null;
}

// Update an existing booking's calendar event (time/duration/summary/room moved).
// Handles a room change by moving the event to the correct calendar (delete +
// recreate) since a Google Calendar event can't be moved between calendars.
// Returns the storedId to save back on the booking row ("calId|eventId"),
// which may be unchanged, or null if there was nothing to update / it failed.
export async function updateBooking(env, { storedId, summary, startUtc, durationMin, roomId, token: preToken }) {
  if (!storedId) return null;
  const [oldCalId, eventId] = storedId.includes('|') ? storedId.split('|') : [null, storedId];
  if (!oldCalId || !eventId) return null;

  const newCalId = calendarId(env, roomId);
  if (!newCalId) return null;

  const token = preToken || await getAccessToken(env);
  if (!token) return null;

  const start = new Date(startUtc + 'Z');
  const end   = new Date(start.getTime() + durationMin * 60000);
  const body  = {
    summary,
    start: { dateTime: start.toISOString() },
    end:   { dateTime: end.toISOString() },
  };

  if (newCalId === oldCalId) {
    // Same calendar: patch the existing event in place.
    const res = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(oldCalId)}/events/${encodeURIComponent(eventId)}`,
      {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      }
    );
    if (!res.ok) return null;
    return storedId;
  }

  // Room moved to a different calendar: create fresh, then clean up the old one.
  const newId = await pushBooking(env, { summary, startUtc, durationMin, roomId, token });
  if (!newId) return null;
  await removeBooking(env, storedId);
  return `${newCalId}|${newId}`;
}

// Remove a booking from its calendar by event id.
// calendarId must be stored alongside gcal_event_id - we encode it as "calId|eventId".
export async function removeBooking(env, storedId) {
  if (!storedId) return;
  const [calId, eventId] = storedId.includes('|') ? storedId.split('|') : [null, storedId];
  if (!calId || !eventId) return;
  const token = await getAccessToken(env);
  if (!token) return;
  await fetch(
    `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calId)}/events/${encodeURIComponent(eventId)}`,
    { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } }
  );
}

export { getAccessToken };
