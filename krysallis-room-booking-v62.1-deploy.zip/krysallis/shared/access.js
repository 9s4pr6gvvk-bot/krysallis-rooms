// Cloudflare Access identity.
//
// When the app is put behind Cloudflare Access, Cloudflare authenticates the
// person at the edge (email + one-time PIN) and forwards a signed JWT with
// their email in the `Cf-Access-Jwt-Assertion` header. This module verifies
// that JWT (signature, issuer, audience, expiry) and returns the email. Nothing
// here trusts a header on its own: an unsigned or wrong-audience token is
// rejected.
//
// Two settings drive it, both set on the live Pages project:
//   ACCESS_TEAM_DOMAIN  e.g. "krysallis.cloudflareaccess.com"  (team domain)
//   ACCESS_AUD          the Application Audience (AUD) tag from the Access app
// If either is missing the module stays inert (returns null), so the app keeps
// working on its existing session until Access is actually turned on.

function b64urlToBytes(str) {
  str = str.replace(/-/g, "+").replace(/_/g, "/");
  while (str.length % 4) str += "=";
  const bin = atob(str);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return arr;
}
function b64urlToString(str) {
  return new TextDecoder().decode(b64urlToBytes(str));
}

// Small in-isolate cache of the Access signing keys, refreshed hourly or on a
// key-id miss (Cloudflare rotates keys every few weeks).
const jwks = { domain: "", keys: {}, fetchedAt: 0 };

async function getKey(teamDomain, kid) {
  const fresh = jwks.domain === teamDomain && (Date.now() - jwks.fetchedAt) < 3600000;
  if (!fresh || !jwks.keys[kid]) {
    try {
      const res = await fetch(`https://${teamDomain}/cdn-cgi/access/certs`);
      if (!res.ok) return null;
      const data = await res.json();
      const map = {};
      for (const jwk of (data.keys || [])) {
        try {
          map[jwk.kid] = await crypto.subtle.importKey(
            "jwk", jwk,
            { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
            false, ["verify"]
          );
        } catch { /* skip a bad key */ }
      }
      jwks.domain = teamDomain;
      jwks.keys = map;
      jwks.fetchedAt = Date.now();
    } catch { return null; }
  }
  return jwks.keys[kid] || null;
}

function normaliseDomain(d) {
  return String(d || "").trim().replace(/^https?:\/\//, "").replace(/\/+$/, "");
}

// Returns the verified email, or null if Access is not configured or the token
// is missing/invalid.
export async function verifyAccess(context) {
  const { request, env } = context;
  const teamDomain = normaliseDomain(env.ACCESS_TEAM_DOMAIN);
  const aud = (env.ACCESS_AUD || "").trim();
  if (!teamDomain || !aud) return null; // Access not wired up yet

  let token = request.headers.get("Cf-Access-Jwt-Assertion") || "";
  if (!token) {
    const m = (request.headers.get("Cookie") || "").match(/(?:^|; )CF_Authorization=([^;]+)/);
    if (m) token = m[1];
  }
  if (!token || token.split(".").length !== 3) return null;

  const [h, p, s] = token.split(".");
  let header, payload;
  try {
    header = JSON.parse(b64urlToString(h));
    payload = JSON.parse(b64urlToString(p));
  } catch { return null; }

  if (header.alg !== "RS256" || !header.kid) return null;

  const key = await getKey(teamDomain, header.kid);
  if (!key) return null;

  const ok = await crypto.subtle.verify(
    "RSASSA-PKCS1-v1_5", key,
    b64urlToBytes(s),
    new TextEncoder().encode(h + "." + p)
  );
  if (!ok) return null;

  // Claims.
  const now = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < now) return null;
  if (payload.nbf && payload.nbf > now + 60) return null;
  if (payload.iss && payload.iss !== `https://${teamDomain}`) return null;
  const audOk = Array.isArray(payload.aud) ? payload.aud.includes(aud) : payload.aud === aud;
  if (!audOk) return null;

  const email = (payload.email || "").toString().trim().toLowerCase();
  return email || null;
}
