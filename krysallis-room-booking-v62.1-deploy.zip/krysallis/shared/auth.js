// Signed session cookies (HMAC-SHA256, Web Crypto, no dependencies) plus the
// identity resolver. Two ways in are supported, checked in this order:
//   1. A signed session cookie (used by the developer "view as" feature and by
//      any legacy magic-link / demo session).
//   2. Cloudflare Access: a signature-verified Access JWT whose email maps to an
//      active practitioner. This is the primary path once the app is placed
//      behind Access. Practitioners never have passwords.
import { verifyAccess } from "./access.js";

const COOKIE = "krys_session";
const MAX_AGE = 60 * 60 * 24 * 14; // 14 days (sign in about once a fortnight)

function b64urlEncode(bytes) {
  let bin = "";
  const arr = new Uint8Array(bytes);
  for (let i = 0; i < arr.length; i++) bin += String.fromCharCode(arr[i]);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function b64urlDecode(str) {
  str = str.replace(/-/g, "+").replace(/_/g, "/");
  while (str.length % 4) str += "=";
  const bin = atob(str);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return arr;
}
async function hmacKey(secret) {
  return crypto.subtle.importKey(
    "raw", new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]
  );
}

// payload carries the practitioner id, email and admin flag.
export async function createToken(secret, payload) {
  const body = { ...payload, exp: Math.floor(Date.now() / 1000) + MAX_AGE };
  const bytes = new TextEncoder().encode(JSON.stringify(body));
  const key = await hmacKey(secret);
  const sig = await crypto.subtle.sign("HMAC", key, bytes);
  return b64urlEncode(bytes) + "." + b64urlEncode(sig);
}

export async function verifyToken(secret, token) {
  if (!token || !token.includes(".")) return null;
  const [p, s] = token.split(".");
  let payloadBytes, sigBytes;
  try { payloadBytes = b64urlDecode(p); sigBytes = b64urlDecode(s); } catch { return null; }
  const key = await hmacKey(secret);
  const ok = await crypto.subtle.verify("HMAC", key, sigBytes, payloadBytes);
  if (!ok) return null;
  let payload;
  try { payload = JSON.parse(new TextDecoder().decode(payloadBytes)); } catch { return null; }
  if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
  return payload;
}

export function readCookie(request, name = COOKIE) {
  const header = request.headers.get("Cookie") || "";
  const match = header.match(new RegExp("(?:^|; )" + name + "=([^;]+)"));
  return match ? decodeURIComponent(match[1]) : null;
}
export function sessionCookie(token) {
  return `${COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${MAX_AGE}`;
}
export function clearCookie() {
  return `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;
}

// Shape the app expects for a signed-in practitioner. Returns null if the row
// is missing or inactive, so nobody keeps access after being deactivated.
function sessionFromRow(row) {
  if (!row || !row.active) return null;
  const dev = !!row.is_developer;
  return { pid: row.id, name: row.name, email: row.email, admin: !!row.is_admin || dev, developer: dev };
}
async function practitionerById(env, id) {
  try {
    const row = await env.DB.prepare(
      "SELECT id, name, email, is_admin, is_developer, active FROM practitioners WHERE id = ?"
    ).bind(id).first();
    return sessionFromRow(row);
  } catch { return null; }
}
async function practitionerByEmail(env, email) {
  try {
    const row = await env.DB.prepare(
      "SELECT id, name, email, is_admin, is_developer, active FROM practitioners WHERE lower(email) = ?"
    ).bind((email || "").toLowerCase()).first();
    return sessionFromRow(row);
  } catch { return null; }
}

// Returns the live practitioner record if the request carries a valid identity
// AND that practitioner is still active. Never trusts a cookie or header alone.
export async function getSession(context) {
  // 1) Signed session cookie (developer impersonation, legacy magic-link/demo).
  //    Checked first so "view as therapist" overrides the real Access identity.
  const secret = context.env.SESSION_SECRET;
  if (secret) {
    const payload = await verifyToken(secret, readCookie(context.request));
    if (payload && payload.pid) {
      const s = await practitionerById(context.env, payload.pid);
      if (s) return s;
    }
  }
  // 2) Cloudflare Access identity (primary once Access is enabled).
  try {
    const email = await verifyAccess(context);
    if (email) {
      const s = await practitionerByEmail(context.env, email);
      if (s) return s;
    }
  } catch { /* fall through to no session */ }
  return null;
}

// The verified Access email even when it is NOT a known practitioner. Lets the
// portal show "you are signed in but not set up yet" instead of a login form.
export async function getAccessEmail(context) {
  try { return await verifyAccess(context); } catch { return null; }
}
