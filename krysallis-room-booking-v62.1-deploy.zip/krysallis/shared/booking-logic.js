// Core booking rules for Krysallis: settings, timezone maths, per-room
// availability, conflict detection, rate selection and the notice-period rule.
// Times are reasoned about in the configured timezone but stored/compared as
// minute-precision UTC ISO strings (e.g. 2026-08-26T13:00), same as WC.

const DEFAULTS = {
  open_days: "0,1,2,3,4,5,6",
  open_start: "00:00",
  open_end: "24:00",
  slot_step_min: "15",
  notice_hours: "24",
  timezone: "Europe/London",
  rate_adhoc_pence: "1450",
  rate_block_pence: "1100",
  block_min_minutes: "240",
  horizon_days: "365",
  max_duration_min: "480",
};

export const SETTING_KEYS = Object.keys(DEFAULTS);

export async function getSettings(env) {
  const out = { ...DEFAULTS };
  try {
    const { results } = await env.DB.prepare("SELECT key, value FROM app_settings").all();
    for (const r of results || []) if (r.key in out) out[r.key] = r.value;
  } catch { /* defaults are fine */ }
  return {
    days: out.open_days.split(",").map((s) => parseInt(s, 10)).filter((n) => !isNaN(n)),
    start: out.open_start,
    end: out.open_end,
    step: Math.max(5, parseInt(out.slot_step_min, 10) || 15),
    noticeHours: Math.max(0, parseInt(out.notice_hours, 10) || 24),
    timezone: out.timezone || "Europe/London",
    rateAdhoc: parseInt(out.rate_adhoc_pence, 10) || 1450,
    rateBlock: parseInt(out.rate_block_pence, 10) || 1100,
    blockMin: parseInt(out.block_min_minutes, 10) || 240,
    horizon: Math.min(730, Math.max(1, parseInt(out.horizon_days, 10) || 365)),
    maxDuration: Math.min(720, Math.max(30, parseInt(out.max_duration_min, 10) || 480)),
  };
}

function tzParts(date, timeZone) {
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  });
  const p = {};
  for (const part of fmt.formatToParts(date)) p[part.type] = part.value;
  return p;
}
function tzOffsetMinutes(date, timeZone) {
  const p = tzParts(date, timeZone);
  const asUTC = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second);
  return Math.round((asUTC - date.getTime()) / 60000);
}
// Wall-clock time in timeZone -> real UTC Date.
export function wallToUTC(y, m, d, hh, mm, timeZone) {
  const guess = new Date(Date.UTC(y, m - 1, d, hh, mm));
  const off = tzOffsetMinutes(guess, timeZone);
  return new Date(guess.getTime() - off * 60000);
}
function hm(str) { const [h, m] = (str || "0:0").split(":").map((n) => parseInt(n, 10) || 0); return h * 60 + m; }
function pad(n) { return String(n).padStart(2, "0"); }
export function utcIso(date) {
  return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())}T${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}`;
}
export function endIso(startIso, durationMin) {
  const d = new Date(startIso + "Z");
  return utcIso(new Date(d.getTime() + durationMin * 60000));
}

// The local (Europe/London) wall clock behind a stored UTC time.
export function wallParts(startIso, timeZone) {
  const p = tzParts(new Date(startIso + "Z"), timeZone);
  return { y: +p.year, m: +p.month, d: +p.day, hh: +p.hour, mm: +p.minute };
}
// Local calendar date (YYYY-MM-DD) of a stored UTC time.
export function localDate(startIso, timeZone) {
  const w = wallParts(startIso, timeZone);
  return `${w.y}-${pad(w.m)}-${pad(w.d)}`;
}
// Add whole weeks while KEEPING THE SAME WALL-CLOCK TIME. Adding 7*24h in UTC
// silently shifts a 10am session to 9am or 11am across a clock change, so
// recurring series are stepped in local calendar days and converted back.
export function addWeeksIso(startIso, weeks, timeZone) {
  const w = wallParts(startIso, timeZone);
  const base = new Date(Date.UTC(w.y, w.m - 1, w.d));
  base.setUTCDate(base.getUTCDate() + weeks * 7);
  return utcIso(wallToUTC(base.getUTCFullYear(), base.getUTCMonth() + 1, base.getUTCDate(), w.hh, w.mm, timeZone));
}

// Every occurrence of a repeating booking.
//   intervalWeeks : 1 = weekly, 2 = every two weeks
//   count         : total number of sessions (used when untilDate is null)
//   untilDate     : YYYY-MM-DD, inclusive; the series ends on or before this day
export function buildOccurrences(startIso, {
  intervalWeeks = 1, count = 1, untilDate = null,
  timeZone = "Europe/London", maxOccurrences = 104,
} = {}) {
  const out = [startIso];
  const step = Math.max(1, Math.min(8, parseInt(intervalWeeks, 10) || 1));
  if (untilDate) {
    for (let i = 1; i < maxOccurrences; i++) {
      const occ = addWeeksIso(startIso, i * step, timeZone);
      if (localDate(occ, timeZone) > untilDate) break;
      out.push(occ);
    }
    return out;
  }
  const n = Math.max(1, Math.min(maxOccurrences, parseInt(count, 10) || 1));
  for (let i = 1; i < n; i++) out.push(addWeeksIso(startIso, i * step, timeZone));
  return out;
}

// Candidate start times for one room on one calendar date (YYYY-MM-DD in tz),
// minus any that collide with an existing confirmed booking in that room.
// `wantDuration` lets us only offer starts that actually fit before closing
// and don't overlap something already booked.
export async function roomDayAvailability(env, settings, roomId, dateStr, wantDuration) {
  const s = settings;
  const [y, mo, d] = dateStr.split("-").map((n) => parseInt(n, 10));
  const dow = new Date(Date.UTC(y, mo - 1, d)).getUTCDay();
  if (!s.days.includes(dow)) return [];

  const existing = await roomBookingsOnDate(env, roomId, y, mo, d, s.timezone);
  const startMin = hm(s.start), endMin = hm(s.end);
  const dur = wantDuration || s.step;
  const out = [];
  for (let t = startMin; t + dur <= endMin; t += s.step) {
    const hh = Math.floor(t / 60), mm = t % 60;
    const startUTC = wallToUTC(y, mo, d, hh, mm, s.timezone);
    const start = utcIso(startUTC);
    const end = endIso(start, dur);
    if (existing.some((b) => overlaps(start, end, b.start, b.end))) continue;
    if (startUTC < new Date()) continue;
    out.push({ start, label: timeLabel(startUTC, s.timezone) });
  }
  return out;
}

async function roomBookingsOnDate(env, roomId, y, mo, d, tz) {
  // Pull the room's confirmed bookings for the day (compare on the UTC window).
  // Widened by a day either side so a long session starting late the night
  // before is still seen as blocking this morning.
  const dayStart = utcIso(new Date(wallToUTC(y, mo, d, 0, 0, tz).getTime() - 86400000));
  const dayEnd = utcIso(wallToUTC(y, mo, d, 23, 59, tz));
  const { results } = await env.DB.prepare(
    "SELECT start_utc, duration_min FROM bookings WHERE room_id = ? AND status = 'confirmed' AND start_utc BETWEEN ? AND ?"
  ).bind(roomId, dayStart, dayEnd).all();
  return (results || []).map((r) => ({ start: r.start_utc, end: endIso(r.start_utc, r.duration_min) }));
}

export function overlaps(aStart, aEnd, bStart, bEnd) {
  return aStart < bEnd && bStart < aEnd;
}

// Is a proposed booking free in its room? Checks every confirmed booking that
// could overlap. Used server-side on create so nothing slips through the UI.
export async function isRoomFree(env, roomId, startIso, durationMin, ignoreId) {
  const end = endIso(startIso, durationMin);
  // A day either side covers any realistic overlap window.
  const lo = utcIso(new Date(new Date(startIso + "Z").getTime() - 86400000));
  const hi = utcIso(new Date(new Date(startIso + "Z").getTime() + 86400000));
  const { results } = await env.DB.prepare(
    "SELECT id, start_utc, duration_min FROM bookings WHERE room_id = ? AND status = 'confirmed' AND start_utc BETWEEN ? AND ?"
  ).bind(roomId, lo, hi).all();
  for (const r of results || []) {
    if (ignoreId && r.id === ignoreId) continue;
    if (overlaps(startIso, end, r.start_utc, endIso(r.start_utc, r.duration_min))) return false;
  }
  return true;
}

// Rate per hour in pence. Krysallis-referred sessions carry no room charge.
// Any single booking of block_min_minutes (4 hours) or longer earns the block
// rate, whether it's a one-off or part of a series; everything else is ad hoc.
export function rateForBooking(settings, { clientType, durationMin }) {
  if (clientType === "referred") return 0;
  if (durationMin >= settings.blockMin) return settings.rateBlock;
  return settings.rateAdhoc;
}

// Hours until a booking starts, from now. Negative if already started.
export function hoursUntil(startIso) {
  return (new Date(startIso + "Z").getTime() - Date.now()) / 3600000;
}

// Inside the notice window (or already started/passed)? Practitioners cannot
// remove these themselves; Krysallis admin has to do it.
export function insideNotice(startIso, noticeHours) {
  return hoursUntil(startIso) < noticeHours;
}

export function timeLabel(date, timeZone) {
  return new Intl.DateTimeFormat("en-GB", { timeZone, hour: "numeric", minute: "2-digit", hour12: true })
    .format(date).replace(/\s?([ap])m/i, (m, g) => " " + g.toLowerCase() + "m");
}
export function formatSlot(startIso, timeZone = "Europe/London") {
  const d = new Date(startIso + "Z");
  const date = new Intl.DateTimeFormat("en-GB", { timeZone, weekday: "short", day: "numeric", month: "short", year: "numeric" }).format(d);
  return `${date}, ${timeLabel(d, timeZone)}`;
}
