// Sign-in log helper. Records one row per step of the magic-link flow into the
// auth_log table so a failed sign-in can be traced later from the admin
// console. Best effort only: logging never throws and never blocks or breaks
// the sign-in itself. If the table is missing (migration not run yet) the
// insert is swallowed silently.

export async function logAuth(env, { email, event, detail, request } = {}) {
  try {
    let ip = "", ua = "";
    if (request) {
      ip = request.headers.get("CF-Connecting-IP") || "";
      ua = (request.headers.get("User-Agent") || "").slice(0, 300);
    }
    await env.DB.prepare(
      "INSERT INTO auth_log (email, event, detail, ip, ua) VALUES (?, ?, ?, ?, ?)"
    ).bind((email || "").toString().toLowerCase().slice(0, 200), event, detail || "", ip, ua).run();
  } catch { /* logging must never break the flow */ }
}
