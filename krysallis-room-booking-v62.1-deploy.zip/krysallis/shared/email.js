// Resend wrapper + a small set of email-safe UI components. No-ops safely until
// RESEND_API_KEY is set, so the whole system works in testing before email is
// wired up (mirrors the WC setup).
//   RESEND_API_KEY   Resend API key (secret)
//   BOOKING_FROM     verified sender, e.g. "Krysallis Rooms <rooms@mail.krysallisroombooking.co.uk>"
//   ADMIN_EMAIL      where admin copies go (Paddy), e.g. "rooms@krysallis.org.uk"
//   SITE_URL         public origin, e.g. "https://krysallisroombooking.co.uk"

export async function sendEmail(env, { to, subject, html, replyTo }) {
  const key = env.RESEND_API_KEY;
  if (!key) { console.log("[email] no RESEND_API_KEY; skip", to, "-", subject); return { skipped: true }; }
  const from = env.BOOKING_FROM || "Krysallis Rooms <onboarding@resend.dev>";
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to: Array.isArray(to) ? to : [to], subject, html, ...(replyTo ? { reply_to: replyTo } : {}) }),
    });
    if (!res.ok) { console.log("[email] Resend error", res.status, await res.text()); return { ok: false }; }
    return { ok: true };
  } catch (e) { console.log("[email] failed", e && e.message); return { ok: false }; }
}

export function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

// ── Type stacks ───────────────────────────────────────────────────────────────
// The portal uses Fraunces (serif display) + Mulish (sans body). Most email
// clients strip web fonts, so each element carries a solid fallback stack and
// the web fonts are a progressive enhancement for clients that honour <link>
// (Apple Mail, iOS Mail). Georgia stands in for Fraunces, the system UI stack
// for Mulish, so the brand reads the same even where the web fonts are dropped.
const SERIF = "'Fraunces', Georgia, 'Times New Roman', serif";
const SANS = "'Mulish', -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif";
const FONTS = "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Mulish:wght@400;500;600;700&display=swap";
// The Krysallis wordmark (cream), hosted on the sending domain so it isn't
// blocked and doesn't trip Resend's "host images on the sending domain" check.
// Sits on a green header band, which keeps it legible in light and dark alike.
const LOGO = "https://krysallisroombooking.co.uk/email/krysallis-logo.png";

// ── Components ────────────────────────────────────────────────────────────────
// Every component sets its own inline (light) styles so no-CSS clients such as
// Gmail render correctly, and carries a class so the dark-mode block in the
// shell can recolour it. Pass already-escaped content.

export function emailTitle(text) {
  return `<h1 class="e-title" style="margin:0 0 18px;font-family:${SERIF};font-size:22px;font-weight:600;color:#2c4438;line-height:1.3">${text}</h1>`;
}

export function emailText(html, { muted = false } = {}) {
  const cls = muted ? "e-muted" : "e-text";
  const color = muted ? "#5a6b63" : "#3f4b45";
  return `<p class="${cls}" style="margin:0 0 16px;font-family:${SANS};font-size:15px;line-height:1.6;color:${color}">${html}</p>`;
}

// rows: array of [label, value] pairs (already escaped). Falsy entries skipped.
export function emailDetails(rows) {
  const body = rows.filter(Boolean).map(([label, value]) =>
    `<tr>
      <td class="e-row-label" style="padding:10px 16px;font-family:${SANS};font-size:13px;color:#5a6b63;white-space:nowrap;width:120px;border-bottom:1px solid rgba(34,48,42,.06)">${label}</td>
      <td class="e-row-value" style="padding:10px 16px;font-family:${SANS};font-size:14px;font-weight:600;color:#22302a;border-bottom:1px solid rgba(34,48,42,.06)">${value}</td>
    </tr>`).join("");
  return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="e-panel" style="width:100%;background:#f4f7f5;border-radius:8px;margin:0 0 20px">${body}</table>`;
}

export function emailButton(href, label) {
  return `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:4px auto 20px">
    <tr><td align="center" class="e-btn" style="border-radius:6px;background:#2c4438">
      <a href="${href}" style="display:inline-block;padding:14px 34px;font-family:${SANS};font-size:15px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:6px">${label}</a>
    </td></tr></table>`;
}

// A large, centred one-time code. Used for the sign-in email. No link, so mail
// scanners and privacy prefetchers cannot consume it.
export function emailCode(code) {
  return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:4px 0 20px">
    <tr><td align="center" class="e-panel" style="background:#f4f7f5;border-radius:8px;padding:22px 16px">
      <div class="e-muted" style="font-family:${SANS};font-size:12px;letter-spacing:2px;text-transform:uppercase;color:#5a6b63;margin-bottom:10px">Your sign-in code</div>
      <div class="e-title" style="font-family:'SF Mono','SFMono-Regular',Menlo,Consolas,monospace;font-size:34px;font-weight:700;letter-spacing:8px;color:#2c4438">${esc(code)}</div>
    </td></tr></table>`;
}

export function emailNote(html, { tone = "muted" } = {}) {
  const warn = tone === "warn";
  return `<p class="${warn ? "e-warn" : "e-muted"}" style="margin:0 0 4px;font-family:${SANS};font-size:13px;line-height:1.55;color:${warn ? "#8a2b2b" : "#5a6b63"}">${html}</p>`;
}

export function emailSpacer(px = 14) {
  return `<div style="line-height:${px}px;height:${px}px;font-size:1px">&nbsp;</div>`;
}

// ── Shell ─────────────────────────────────────────────────────────────────────
// A full HTML document: a centred card with a typographic Krysallis wordmark
// (no external image, so nothing is hosted off the sending domain and nothing
// breaks when a client blocks remote images). Declares color-scheme and ships
// an explicit dark palette, keyed to the component classes and mirrored for the
// [data-ogsc]/[data-ogsb] attributes some clients add when forcing dark, so it
// stays legible instead of being blindly inverted.
export function emailShell(inner, { preheader = "" } = {}) {
  return `<!DOCTYPE html>
<html lang="en" style="margin:0;padding:0">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="x-apple-disable-message-reformatting">
<meta name="color-scheme" content="light dark">
<meta name="supported-color-schemes" content="light dark">
<title>Krysallis Room Booking</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="${FONTS}" rel="stylesheet">
<style>
  :root { color-scheme: light dark; supported-color-schemes: light dark; }
  body { margin:0; padding:0; width:100% !important; -webkit-text-size-adjust:100%; }
  a { color:#2c4438; }
  @media (prefers-color-scheme: dark) {
    .e-bg { background:#141a16 !important; }
    .e-card { background:#1e2621 !important; border-color:#30392f !important; }
    .e-eyebrow, .e-muted, .e-row-label { color:#93a49a !important; }
    .e-title, .e-row-value { color:#eef4ef !important; }
    .e-text { color:#cdd6d0 !important; }
    .e-panel { background:#26302a !important; }
    .e-warn { color:#f0a3a3 !important; }
    .e-footer { color:#78837c !important; }
    a { color:#a9c4b4 !important; }
    .e-btn, .e-btn a { background:#3c5a4b !important; color:#ffffff !important; }
  }
  [data-ogsc] .e-bg { background:#141a16 !important; }
  [data-ogsc] .e-card { background:#1e2621 !important; border-color:#30392f !important; }
  [data-ogsc] .e-eyebrow { color:#dfeae1 !important; }
  [data-ogsc] .e-muted, [data-ogsc] .e-row-label { color:#93a49a !important; }
  [data-ogsc] .e-title, [data-ogsc] .e-row-value { color:#eef4ef !important; }
  [data-ogsc] .e-text { color:#cdd6d0 !important; }
  [data-ogsc] .e-panel { background:#26302a !important; }
  [data-ogsc] .e-warn { color:#f0a3a3 !important; }
  [data-ogsc] .e-footer { color:#78837c !important; }
</style>
</head>
<body class="e-bg" style="margin:0;padding:0;background:#f6f4ef;font-family:${SANS}">
  <div style="display:none;max-height:0;overflow:hidden;opacity:0;mso-hide:all">${esc(preheader)}</div>
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="e-bg" style="background:#f6f4ef">
    <tr><td align="center" style="padding:24px 12px">
      <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="width:560px;max-width:560px">
        <tr><td class="e-band" style="background:#2c4438;border-radius:10px 10px 0 0;padding:26px 28px 22px" bgcolor="#2c4438">
          <img src="${LOGO}" width="150" alt="Krysallis" style="width:150px;max-width:60%;height:auto;display:block;border:0;outline:none;text-decoration:none">
          <div class="e-eyebrow" style="font-family:${SANS};font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#c7d6cb;margin-top:12px">Room Booking</div>
        </td></tr>
        <tr><td class="e-card" style="background:#ffffff;border:1px solid #e0ded4;border-top:none;border-radius:0 0 10px 10px;padding:28px">
          ${inner}
        </td></tr>
        <tr><td class="e-footer" style="padding:16px 28px 4px;text-align:center;font-family:${SANS};font-size:12px;line-height:1.5;color:#8a938d">
          krysallisroombooking.co.uk
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}
