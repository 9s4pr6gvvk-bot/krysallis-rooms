# Krysallis room booking - v47 deploy notes (Franks Media)

New in this build: the **All rooms** calendar. No database changes, no
migration, no new secrets. Deploy the code as usual.

## The problem this fixes

The grid only ever showed one room. If the time a therapist wanted was taken in
three rooms, they had to open all four tabs to find the fourth. On a phone it
was four separate lists.

## What changed

**One calendar for all four rooms.** "All rooms" is now the first tab and the
default view, on desktop and on the phone. The grid says one thing: pale green
is time that is free in at least one room, plain white is time that is not.
Nothing is written on the blocks at all.

Hovering highlights the exact session you would take and shows one small label:
the start and end time of that session, and the rooms free at that moment. One
label for the session, not one per 15 minutes. The label rides just off the
cursor rather than sitting under it, so reading it never means moving the mouse
onto a different time. Clicking opens the
confirmation panel, where you choose the room if there is more than one; the
label on the grid follows whichever room you pick. Individual room tabs are
unchanged and still show who else is in, by name.

In the all rooms view, other therapists' bookings are not drawn individually:
time that is fully taken simply reads as unavailable. Your own bookings show as
a green edge on the open time, so they never hide the fact that another room is
free at that moment.

**One request per week instead of one per room per day.** New endpoint
`GET /api/week?from=YYYY-MM-DD&days=7` returns every active room, every
confirmed booking in the window, and the booking rules, in a single call backed
by one database query. The portal works out free times from that payload in the
browser, so switching room or session length is instant and costs nothing. A
week render went from 8 requests to 1.

`/api/availability` and `/api/room-bookings` are untouched and still work;
the portal no longer calls them.

**Free times are now worked out in the browser.** The server still re-checks
every booking on create (`isRoomFree`), so nothing can slip through, and
`/api/bookings` now also refuses a start time that has already passed for
practitioners, in case a device clock is wrong. Admin can still record a past
session.

## Checks run before release

- Browser time maths compared against the server's own `wallToUTC` across both
  2026 clock changes: identical on all 768 sampled times.
- Availability derived in the browser compared against the server's
  `roomDayAvailability` over a randomised week spanning the October clock
  change: identical on all 84 room-days, at 60, 90 and 120 minute sessions.
- Portal loaded headless against a stubbed API: all rooms view, chips, room
  chooser, single-room tabs, week navigation, and the no-refetch behaviour on
  room and duration changes.

## Worth knowing

- There is one way to book: click the time, then pick the room. Nothing on the
  grid is separately clickable, so there is no wrong thing to click.
- Free time now draws as one continuous block, however the rooms behind it
  change through the day. The rooms named in the label belong to the slot under
  the cursor, so they stay correct as you move down a long block.
- The room numbers in the label come from the room name, so "Room 3" shows as 3.
  A room named something else shows its first letter instead.
- Nothing about rates, repeats, cancellation rules, invoicing or email changed.
