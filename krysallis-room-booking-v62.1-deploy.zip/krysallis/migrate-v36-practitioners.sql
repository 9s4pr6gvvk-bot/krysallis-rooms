-- migrate-v36-practitioners: update all practitioner emails and names
-- Safe to run: all booking/agreement reassignments happen before any DELETE
-- Apply with: npx wrangler d1 execute krysallis-cms --remote --file=./migrate-v36-practitioners.sql

-- ============================================================
-- STEP 1: UPDATE existing records (placeholder → real email)
-- ============================================================

UPDATE practitioners SET name = 'Sarah Latham',      email = 'helloslatham@gmail.com'                    WHERE email = 'sarahl@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Jane Troughton',    email = 'jtroughton7@gmail.com'                     WHERE email = 'janetroughton@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Claire Judd',       email = 'clairejuddtherapy@gmail.com'               WHERE email = 'clairejudd@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Alexandra McKibbin',email = 'alexandramckibbin@gmail.com'                WHERE email = 'alexandram@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Zoe Martin',        email = 'ZoeMtherapy@outlook.com'                   WHERE email = 'zoe@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Sara Caswell',      email = 'saracaswell18@gmail.com'                   WHERE email = 'saracaswell@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Sarah Teece',       email = 'sarah.teece@yorklearningeducation.co.uk'   WHERE email = 'saraht@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Sue Allen',         email = 'sueallentherapymatters@gmail.com'          WHERE email = 'sueallen@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Lisa McKendrick',   email = 'l.mckendrick18@gmail.com'                  WHERE email = 'lisam@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Alexandra Bailey',  email = 'ab.integrativetherapy@gmail.com'           WHERE email = 'alexb@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Tammy Golding',     email = 'tammyharrogatecounselling@gmail.com'       WHERE email = 'tammy@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Leah Pryce',        email = 'leahprysce@gmail.com'                      WHERE email = 'leahp@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Caroline Smith',    email = 'carolineeg68@gmail.com'                    WHERE email = 'carolines@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Craig Connell',     email = 'cjconnell14@gmail.com'                     WHERE email = 'craigc@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Madeleine Kingsley',email = 'madeleine.kingsley@gmail.com'              WHERE email = 'madeleinik@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Jo Cheetham',       email = 'jocheetham.therapy@gmail.com'              WHERE email = 'joc@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Viv Easton',        email = 'eastonvivien1@gmail.com'                   WHERE email = 'vive@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Rebecca Bussy',     email = 'counselling@rebeccabussy.com'              WHERE email = 'rebeccab@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Stella Forster',    email = 'stellaforster04@gmail.com'                 WHERE email = 'stellaf@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Elaine Collins',    email = 'elainecollinscounselling@yahoo.com'        WHERE email = 'elaine@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Michaela Hanna',    email = 'michaelahanna81@gmail.com'                 WHERE email = 'michaelah@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Susannah Jaeger',   email = 'jaegersusannah@gmail.com'                  WHERE email = 'susannahj@krysallis-placeholder.local';
UPDATE practitioners SET name = 'Alex Hannay',       email = 'alexhannay@fluentfield.co.uk'              WHERE email = 'alexm@krysallis-placeholder.local';

-- ============================================================
-- STEP 2: MERGE duplicates — reassign bookings and agreements
-- to the surviving record BEFORE deleting the duplicate
-- ============================================================

-- Jane T → Jane Troughton (jtroughton7@gmail.com)
UPDATE bookings
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'jtroughton7@gmail.com')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'janet@krysallis-placeholder.local');
UPDATE monthly_agreements
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'jtroughton7@gmail.com')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'janet@krysallis-placeholder.local');
DELETE FROM practitioners WHERE email = 'janet@krysallis-placeholder.local';

-- Elaine C → Elaine Collins (elainecollinscounselling@yahoo.com)
UPDATE bookings
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'elainecollinscounselling@yahoo.com')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'elainec@krysallis-placeholder.local');
UPDATE monthly_agreements
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'elainecollinscounselling@yahoo.com')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'elainec@krysallis-placeholder.local');
DELETE FROM practitioners WHERE email = 'elainec@krysallis-placeholder.local';

-- JO C → Jo Cheetham (jocheetham.therapy@gmail.com)
UPDATE bookings
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'jocheetham.therapy@gmail.com')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'jocheetham@krysallis-placeholder.local');
UPDATE monthly_agreements
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'jocheetham.therapy@gmail.com')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'jocheetham@krysallis-placeholder.local');
DELETE FROM practitioners WHERE email = 'jocheetham@krysallis-placeholder.local';

-- Craig Connell duplicate → Craig Connell (cjconnell14@gmail.com)
UPDATE bookings
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'cjconnell14@gmail.com')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'craigconnell@krysallis-placeholder.local');
UPDATE monthly_agreements
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'cjconnell14@gmail.com')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'craigconnell@krysallis-placeholder.local');
DELETE FROM practitioners WHERE email = 'craigconnell@krysallis-placeholder.local';

-- Michaela → Michaela Hanna (michaelahanna81@gmail.com)
UPDATE bookings
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'michaelahanna81@gmail.com')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'michaela@krysallis-placeholder.local');
UPDATE monthly_agreements
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'michaelahanna81@gmail.com')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'michaela@krysallis-placeholder.local');
DELETE FROM practitioners WHERE email = 'michaela@krysallis-placeholder.local';

-- ============================================================
-- STEP 3: REMOVE test/redundant accounts (no future bookings)
-- ============================================================

DELETE FROM practitioners WHERE email = 'test@test.uk';

-- ============================================================
-- STEP 4: ADD new practitioners not yet in the system
-- ============================================================

INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Nicky Shamir',     'nicky.shamir@clarityharrogate.co.uk', 0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Gerry Spencer',    'gerry.spencer8@icloud.com',           0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Sue Murphy',       'suemurphycounsellor@aol.co.uk',       0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Lesley Hitchen',   'lesley.hitchen01@icloud.com',         0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Rebecca Maunder',  'maunderrebecca@gmail.com',            0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Nigel Turner',     'nturnercounselling@gmail.com',        0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Rachel Rogers',    'rachelrogers1@gmail.com',             0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Sharon Jackson',   'ssjackson2000@gmail.com',             0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Tamsin Fazan',     'tamsinfazan@googlemail.com',          0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Jenny O''Malley',  'jennyomalley85@gmail.com',            0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Julie Barlow',     'barlowjulie3@gmail.com',             0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Sarah Collingwood','sarahcollingwood61@gmail.com',        0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Andrea Bethell',   'andrea.bethell@icloud.com',           0, 1);
INSERT OR IGNORE INTO practitioners (name, email, is_admin, active) VALUES ('Samantha Ashley',  'samantha.e.ashley@gmail.com',         0, 1);

-- Remove therapistnicky - unconfirmed account, replaced by nicky.shamir@clarityharrogate.co.uk
UPDATE bookings
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'nicky.shamir@clarityharrogate.co.uk')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'therapistnicky@gmail.com');
UPDATE monthly_agreements
   SET practitioner_id = (SELECT id FROM practitioners WHERE email = 'nicky.shamir@clarityharrogate.co.uk')
 WHERE practitioner_id = (SELECT id FROM practitioners WHERE email = 'therapistnicky@gmail.com');
DELETE FROM practitioners WHERE email = 'therapistnicky@gmail.com';
