-- migrate-v38-onboarding: one-time first-login booking confirmation gate.
-- Practitioners must confirm (or correct) their seeded recurring bookings the
-- first time they sign in. Admins and the developer are pre-confirmed so they
-- never see the gate. Apply AFTER v37.
-- Apply: npx wrangler d1 execute krysallis-cms --remote --file=./migrate-v38-onboarding.sql

ALTER TABLE practitioners ADD COLUMN bookings_confirmed_at TEXT DEFAULT NULL;

UPDATE practitioners SET bookings_confirmed_at = datetime('now') WHERE is_admin = 1 OR is_developer = 1;
