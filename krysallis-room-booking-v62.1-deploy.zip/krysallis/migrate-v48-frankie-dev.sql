-- Add Frankie (Franks Media dev account) as a practitioner for testing.
-- Safe to run more than once.
INSERT OR IGNORE INTO practitioners (name, email, active)
VALUES ('Frankie (Dev)', 'franksmedia23@gmail.com', 1);
