# Krysallis room booking - v37 deploy notes (Franks Media)

New in this build: `migrate-v37-golive-bookings.sql` - all recurring bookings
rebuilt from the Google Calendar screenshots (56 series, 8,268 rows, 7 Sep 2026
to 3 Sep 2029). Everything else is the existing v36 project, unchanged.

## Deploy quickstart

1. Confirm the live DB is already migrated up to v36 (v37 links practitioners by
   email and needs those records to exist).
2. Go-live only: take a D1 export, then clear the old test/seed data first,
   either by POSTing `/api/reset` `{ "confirm": "RESET" }` as admin, or by
   uncommenting the DELETE line at the top of the v37 file.
3. Apply the bookings:
   `npx wrangler d1 execute krysallis-cms --remote --file=./migrate-v37-golive-bookings.sql`
4. Deploy the site as usual (code is unchanged from v36).
5. Before real launch, do the security items below (disable demo login first).

The v37 file is re-run safe: it clears its own rows (marked
`note='seed:golive-cal'`) before inserting, so running it twice replaces rather
than duplicates. It does NOT touch the old v27 rows - see edge case 2.

## Edge cases and potential issues

1. Run order. v37 must come after v36. If a placeholder email is still present
   or v36 has not run, those inserts fail and the whole transaction rolls back.
   Failure is clean (all or nothing) but nothing seeds.

2. Clear old data first. v37 does not delete the old v27 seeded bookings. Run it
   while v27 rows are still there and the same rooms get two overlapping sets,
   so the calendar double-books. Reset or clear v27 BEFORE running v37.

3. "Until cancelled" is really three years. Rows stop on 3 Sep 2029. Without a
   top-up job the calendar empties then. Build the rolling top-up, or diarise a
   re-run.

4. The seed does not touch Google Calendar. The one-way push lives in
   bookings.js and only fires when a booking is created through the app. A raw
   SQL insert sets no gcal_event_id and pushes nothing, so seeded bookings will
   not appear on the room Google Calendars. Clear the old manual GCal entries
   separately, and decide whether GCal mirroring still matters after go-live.

5. Rooms 2 and 3 were read off the Christmas and New Year weeks. A recurring
   event still shows on a holiday, so what is seeded is reliable, but if anyone
   deleted a holiday instance we would have missed it. Verify Rms 2 and 3
   against a normal week when you can. A few Tue and Wed events also overlapped
   in those screenshots and their exact room or time could not be read cleanly.

6. Sarah Teece Thursday is seeded 2-6pm (from the calendar), not 2-5pm (your
   handover note). Confirm which is right.

7. Paddy's three Room 3 blocks are seeded as chargeable private at the block
   rate. If those are his own holds and should not be billed, they need to be
   referred (rate 0). Same question for any untagged slot that is actually a
   Krysallis referral rather than private.

8. Name mapping judgement calls: "Alex M" = Alex Hannay, "Alex B" = Alexandra
   Bailey, "Alexandra M" = Alexandra McKibbin. Linked by email so a typo cannot
   mislink, but if any of these are the same person on the calendar, some slots
   sit on the wrong record.

9. DST is handled. Times are stored as true UTC, converted per date for BST vs
   GMT, matching how the app saves. Nothing is booked in the 01:00-02:00 window,
   so the twice-a-year clock-change ambiguity does not bite.

10. Session length. The cookie is still 12h (auth.js MAX_AGE). The handover
    wants 30 days - separate change, see the tradeoff note below.

## Security

CRITICAL - remove demo login before real go-live.
`/api/auth/demo` lets any active practitioner's email plus one shared password
sign in as that person. The default is "Huddersfield" and it sits in the repo
(wrangler.toml) and the handover. So anyone with an admin email and that
password gets the admin console; the developer account gets full impersonation
of everyone; it is brute-forceable (no throttling) and it leaks which emails are
registered (404 vs 401). Combined with /api/reset it is one password away from
wiping every booking. Fix: once Resend email is live, switch the portal to the
magic-link flow, then delete functions/api/auth/demo.js and drop it from the
middleware isAuth allowlist. Until then, at minimum set a long private
DEMO_PASSWORD via wrangler secret, but removal is the real fix.

HIGH - no rate limiting on auth endpoints.
/api/auth/demo (password guessing) and /api/auth/request (email and token
flooding) accept unlimited attempts. Add a per-IP or per-email throttle
(Cloudflare rules, or a small D1/KV counter). Less urgent once demo login is
gone, but /api/auth/request should still be capped so it cannot spam
practitioners or bloat auth_tokens.

MEDIUM - reset blast radius.
/api/reset deletes all bookings, agreements and tokens on a single admin call.
Correctly admin-gated, but treat it as one password away from a full wipe while
demo login exists. Take a D1 export before any reset, and consider removing or
second-factoring the endpoint after go-live.

MEDIUM - impersonation is a GET with no CSRF token.
/api/auth/impersonate?id=X needs a developer session (good) but is a GET that
changes session state, and the cookie is SameSite=Lax, so a link a developer
clicks could switch their session. Low harm (developer only, to an existing
active practitioner). Make it a POST with a token if you harden later.

Done right already:
- Sessions are HMAC-signed and re-checked against the live DB every request, so
  a deactivated practitioner loses access at once. Cookie is HttpOnly, Secure,
  SameSite=Lax.
- Magic-link tokens are 256-bit, single-use, 30-min expiry, and
  /api/auth/request never reveals whether an email is registered.
- SESSION_SECRET and API keys are Cloudflare secrets, not in the repo.
- SQL uses bound parameters throughout, so no injection.

Tradeoff - session length. Extending MAX_AGE from 12h to 30 days is fine for the
practitioner portal but widens the window on a shared or lost device. Consider
keeping admin and developer sessions shorter, or accept 30 days for convenience.

Root of trust. Once demo login is gone, the whole system reduces to two things:
the SESSION_SECRET (rotate if ever exposed; rotating logs everyone out, which is
the intended lever) and the Google inboxes that receive magic links. Those
accounts need strong 2FA, because a link to one of them is the only way in.

---

## v38 addition: one-time first-login confirmation gate

New in v38: practitioners must check their seeded regular bookings the first
time they sign in, before they can use the portal. They can edit, remove or add
a series, then confirm. It is genuinely one-time: once confirmed, the gate never
shows again and self-editing is switched back off (ongoing changes go through
the normal admin-mediated flow).

New/changed files: migrate-v38-onboarding.sql, functions/api/onboarding.js
(new), functions/api/me.js (returns `confirmed`), public/portal/index.html (the
gate UI).

Apply order at go-live: v36 -> v37 (bookings) -> v38, then deploy the code.
  npx wrangler d1 execute krysallis-cms --remote --file=./migrate-v38-onboarding.sql

Notes:
- Admins and the developer are pre-confirmed by the migration, so they never see
  the gate.
- me.js reads the flag defensively: if v38 hasn't run (column missing) it
  defaults to confirmed = true, so deploying code before the migration can't lock
  anyone out. Run the migration to actually switch the gate on.
- All day/time edits and additions are computed server-side with the app's
  Europe/London <-> UTC helpers, so BST/GMT and the block rate stay correct, and
  every change is clash-checked against the room.
- Editing a series applies to all future occurrences; changing the weekday keeps
  each occurrence in its own Mon-Sun week. Occurrences that would clash are left
  as they were and the count is reported to the practitioner.
- The gate blocks in the browser (the portal won't render until confirm). The
  API isn't hard-blocked, so the confirm/edit endpoints stay reachable; the
  mutating actions refuse once already confirmed.
