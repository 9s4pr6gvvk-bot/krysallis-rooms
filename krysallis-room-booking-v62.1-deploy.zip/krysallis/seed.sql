-- Starter data for Krysallis. The four therapy rooms only: the shared meeting
-- room is booked through Krysallis central admin on the building-wide Calendly,
-- so it is deliberately not a bookable room here.
INSERT INTO rooms (name, sort_order) VALUES
  ('Room 1', 1), ('Room 2', 2), ('Room 3', 3), ('Room 4', 4);

-- Paddy is the admin. Replace the email before going live.
INSERT INTO practitioners (name, email, is_admin) VALUES
  ('Paddy', 'rooms@krysallis.org.uk', 1);

-- Defaults. Rates are in pence per hour. block_min_minutes is the session
-- length at or above which a booking earns the block rate. notice_hours is the
-- cancellation window: inside it a session stays chargeable and can only be
-- removed by Krysallis admin.
INSERT INTO app_settings (key, value) VALUES
  ('open_days',        '0,1,2,3,4,5,6'),
  ('open_start',       '00:00'),
  ('open_end',         '24:00'),
  ('slot_step_min',    '15'),
  ('notice_hours',     '24'),
  ('timezone',         'Europe/London'),
  ('rate_adhoc_pence', '1450'),
  ('rate_block_pence', '1100'),
  ('block_min_minutes','240'),
  ('horizon_days',     '365'),
  ('max_duration_min', '480');
