-- Krysallis room-booking CMS schema (Cloudflare D1 / SQLite)
-- Apply with:  npx wrangler d1 execute krysallis-cms --remote --file=./schema.sql

-- Bookable rooms.
CREATE TABLE IF NOT EXISTS rooms (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT    NOT NULL,
  sort_order INTEGER DEFAULT 0,
  active     INTEGER DEFAULT 1,
  created_at TEXT    DEFAULT (datetime('now'))
);

-- Practitioners. Identity is the email address; no passwords are stored.
-- Login is by one-time email link. is_admin = 1 grants Paddy the admin area.
CREATE TABLE IF NOT EXISTS practitioners (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT    NOT NULL,
  email      TEXT    NOT NULL UNIQUE,
  is_admin   INTEGER DEFAULT 0,
  active     INTEGER DEFAULT 1,
  created_at TEXT    DEFAULT (datetime('now'))
);

-- One-time login tokens for the magic-link flow. Short-lived, single-use.
CREATE TABLE IF NOT EXISTS auth_tokens (
  token      TEXT PRIMARY KEY,
  email      TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used       INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_auth_email ON auth_tokens(email);

-- Bookings. One row per occurrence. Recurring bookings share a series_id so a
-- whole series can be counted or cancelled together, while conflict-checking
-- and monthly reporting stay simple row-level operations.
--   start_utc  : UTC ISO minute-precision, e.g. 2026-08-26T13:00
--   duration_min: length in minutes
--   client_type: 'private' | 'referred'  (referred = no room charge)
--   kind       : 'adhoc' | 'block'       (block = regular 4h+ rate)
--   rate_pence : charge per hour applied at creation (0 for referred)
--   status     : 'confirmed' | 'cancelled' | 'cancelled_late'
--                cancelled_late keeps the charge (inside the notice window)
CREATE TABLE IF NOT EXISTS bookings (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id       INTEGER NOT NULL,
  practitioner_id INTEGER NOT NULL,
  series_id     TEXT    DEFAULT NULL,
  start_utc     TEXT    NOT NULL,
  duration_min  INTEGER NOT NULL DEFAULT 60,
  client_type   TEXT    DEFAULT 'private',
  kind          TEXT    DEFAULT 'adhoc',
  rate_pence    INTEGER DEFAULT 1450,
  status        TEXT    DEFAULT 'confirmed',
  note          TEXT    DEFAULT '',
  gcal_event_id TEXT    DEFAULT NULL,   -- set once one-way Google Calendar push is wired
  cancelled_at  TEXT    DEFAULT NULL,
  created_at    TEXT    DEFAULT (datetime('now')),
  updated_at    TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_book_room   ON bookings(room_id, start_utc);
CREATE INDEX IF NOT EXISTS idx_book_pract  ON bookings(practitioner_id, start_utc);
CREATE INDEX IF NOT EXISTS idx_book_series ON bookings(series_id);
CREATE INDEX IF NOT EXISTS idx_book_status ON bookings(status);

-- Admin-configurable settings (building hours, rates, notice window, timezone).
CREATE TABLE IF NOT EXISTS app_settings (
  key        TEXT PRIMARY KEY,
  value      TEXT DEFAULT '',
  updated_at TEXT DEFAULT (datetime('now'))
);

-- Monthly agreements ("block deals"): therapists who pay Krysallis a set amount
-- each month for regular fixed time on the calendar, rather than being billed
-- per session. The monthly report and CSV pick these up automatically.
--   amount_pence   : the agreed monthly fee
--   included_hours : private hours the fee covers. 0 = the fee covers them all.
--                    Anything above the included hours is billed at the ad hoc
--                    rate on top, so an overrun is never missed.
--   starts_month   : 'YYYY-MM' the deal begins
--   ends_month     : 'YYYY-MM' the deal ends, or NULL while it is ongoing
CREATE TABLE IF NOT EXISTS monthly_agreements (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  practitioner_id INTEGER NOT NULL,
  amount_pence    INTEGER NOT NULL DEFAULT 0,
  included_hours  REAL    DEFAULT 0,
  note            TEXT    DEFAULT '',
  starts_month    TEXT    NOT NULL,
  ends_month      TEXT    DEFAULT NULL,
  active          INTEGER DEFAULT 1,
  created_at      TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_agree_pract ON monthly_agreements(practitioner_id);

-- Sign-in log (v60): one row per step of the magic-link flow, for diagnosing
-- failed sign-ins from the admin console.
CREATE TABLE IF NOT EXISTS auth_log (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  ts      TEXT DEFAULT (datetime('now')),
  email   TEXT,
  event   TEXT NOT NULL,
  detail  TEXT,
  ip      TEXT,
  ua      TEXT
);
CREATE INDEX IF NOT EXISTS idx_auth_log_ts ON auth_log(ts);
CREATE INDEX IF NOT EXISTS idx_auth_log_email ON auth_log(email);

-- Sign-in codes (v62): 6-digit codes typed on the branded sign-in page, in
-- place of a clickable email link.
CREATE TABLE IF NOT EXISTS auth_codes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  email      TEXT NOT NULL,
  code       TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used       INTEGER DEFAULT 0,
  attempts   INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_auth_codes_email ON auth_codes(email);
CREATE INDEX IF NOT EXISTS idx_auth_codes_expires ON auth_codes(expires_at);
