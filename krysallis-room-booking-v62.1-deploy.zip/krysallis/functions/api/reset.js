// POST /api/reset  – admin-only: wipes all bookings and monthly agreements.
// Intended for clearing test data before go-live. Requires confirmation token.

import { json } from '../../shared/http.js';

export async function onRequestPost(ctx) {
  if (!ctx.data.session?.admin) return json({ error: 'Admins only' }, 403);

  const body = await ctx.request.json().catch(() => ({}));
  if (body.confirm !== 'RESET') {
    return json({ error: 'Send { "confirm": "RESET" } to proceed.' }, 400);
  }

  const db = ctx.env.DB;

  await db.batch([
    db.prepare('DELETE FROM bookings'),
    db.prepare('DELETE FROM monthly_agreements'),
    db.prepare('DELETE FROM auth_tokens'),
  ]);

  return json({ ok: true, message: 'All bookings, agreements and auth tokens cleared.' });
}
