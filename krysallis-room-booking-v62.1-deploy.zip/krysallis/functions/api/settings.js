import { json } from "../../shared/http.js";
import { getSettings, SETTING_KEYS } from "../../shared/booking-logic.js";

// GET   /api/settings  -> the values the front end needs (notice window, rates,
//                         max session length). Any signed-in user.
// PATCH /api/settings  -> admin: change them without touching the code.
export async function onRequestGet(context) {
  const s = await getSettings(context.env);
  return json({
    notice_hours: s.noticeHours,
    rate_adhoc_pence: s.rateAdhoc,
    rate_block_pence: s.rateBlock,
    block_min_minutes: s.blockMin,
    slot_step_min: s.step,
    max_duration_min: s.maxDuration,
    horizon_days: s.horizon,
    timezone: s.timezone,
  });
}

export async function onRequestPatch(context) {
  if (!context.data.session.admin) return json({ error: "Admins only" }, 403);
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const updates = [];
  for (const key of SETTING_KEYS) {
    if (b[key] === undefined) continue;
    updates.push([key, String(b[key]).slice(0, 80)]);
  }
  if (!updates.length) return json({ error: "Nothing to update" }, 400);
  for (const [key, value] of updates) {
    await context.env.DB.prepare(
      "INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = ?, updated_at = datetime('now')"
    ).bind(key, value, value).run();
  }
  return json({ ok: true, updated: updates.length });
}
