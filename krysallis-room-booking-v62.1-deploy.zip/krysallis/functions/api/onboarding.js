import { json } from "../../shared/http.js";
import {
  getSettings, wallParts, wallToUTC, utcIso, isRoomFree, rateForBooking,
} from "../../shared/booking-logic.js";

// First-login booking confirmation for practitioners. Everything that touches
// dates/times runs here on the server, so the same Europe/London <-> UTC rules
// the rest of the app uses apply (no client timezone guessing).
//
// GET  /api/onboarding            -> { confirmed, series:[...], rooms:[...] }
// POST /api/onboarding
//   { action:'confirm' }                                   stamp the flag, unlock the portal
//   { action:'remove-series', series_id }                  cancel that whole future series
//   { action:'edit-series', series_id, weekday?, time?, room_id?, duration_min?, client_type? }
//   { action:'add-series', weekday, time, room_id, duration_min, client_type }
//
// Mutations are refused once the practitioner is already confirmed, so this is
// genuinely a one-time correction window; ongoing changes go through the normal
// booking flow.

const pad = (n) => String(n).padStart(2, "0");
const nowMin = () => new Date().toISOString().slice(0, 16);
const HORIZON_WEEKS = 156; // matches the go-live seed horizon

function utcDay(y, m, d) { return new Date(Date.UTC(y, m - 1, d)).getUTCDay(); } // 0=Sun..6=Sat
function shiftDate(y, m, d, days) {
  const t = new Date(Date.UTC(y, m - 1, d));
  t.setUTCDate(t.getUTCDate() + days);
  return { y: t.getUTCFullYear(), m: t.getUTCMonth() + 1, d: t.getUTCDate() };
}

async function confirmedFlag(env, pid) {
  try {
    const row = await env.DB.prepare("SELECT bookings_confirmed_at FROM practitioners WHERE id = ?").bind(pid).first();
    return !!(row && row.bookings_confirmed_at);
  } catch { return true; }
}

export async function onRequestGet(context) {
  const { env, data } = context;
  const pid = data.session.pid;
  const settings = await getSettings(env);
  const tz = settings.timezone;

  const rooms = ((await env.DB.prepare("SELECT id, name FROM rooms WHERE active = 1 ORDER BY sort_order, id").all()).results) || [];

  const { results } = await env.DB.prepare(
    "SELECT id, room_id, series_id, start_utc, duration_min, client_type FROM bookings " +
    "WHERE practitioner_id = ? AND status = 'confirmed' AND start_utc >= ? ORDER BY start_utc ASC"
  ).bind(pid, nowMin()).all();

  const groups = new Map();
  for (const r of results || []) {
    const key = r.series_id || `one:${r.id}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(r);
  }

  const series = [];
  for (const [key, rows] of groups) {
    // This screen is a one-time confirmation of standing (recurring) bookings.
    // A group with only a single future occurrence is a one-off session, not a
    // regular booking, so it's kept off this list. One-offs still exist and are
    // managed in the portal like any other booking.
    if (rows.length < 2) continue;
    const first = rows[0];
    const wp = wallParts(first.start_utc, tz);
    let frequency = "weekly";
    if (rows.length > 1) {
      const a = new Date(rows[0].start_utc + "Z").getTime();
      const b = new Date(rows[1].start_utc + "Z").getTime();
      if (Math.round((b - a) / 86400000) >= 13) frequency = "fortnightly";
    }
    series.push({
      key,
      series_id: first.series_id || null,
      booking_id: first.id,
      room_id: first.room_id,
      weekday: utcDay(wp.y, wp.m, wp.d),      // 0=Sun..6=Sat, local
      time: `${pad(wp.hh)}:${pad(wp.mm)}`,     // local HH:MM
      duration_min: first.duration_min,
      client_type: first.client_type,
      count: rows.length,
      frequency,
    });
  }

  return json({ confirmed: await confirmedFlag(env, pid), rooms, series });
}

export async function onRequestPost(context) {
  const { env, data } = context;
  const pid = data.session.pid;
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const action = b.action;

  if (action === "confirm") {
    try {
      await env.DB.prepare("UPDATE practitioners SET bookings_confirmed_at = datetime('now') WHERE id = ?").bind(pid).run();
    } catch { return json({ error: "Could not save. Please try again." }, 500); }
    return json({ ok: true });
  }

  // All remaining actions mutate bookings and are only allowed during the
  // one-time window (before the practitioner has confirmed).
  if (await confirmedFlag(env, pid)) {
    return json({ error: "Your bookings are already confirmed. Ask Krysallis to make further changes." }, 403);
  }

  const settings = await getSettings(env);
  const tz = settings.timezone;

  // Load the practitioner's own future rows for a series.
  async function futureRows(seriesId, bookingId) {
    if (seriesId) {
      return ((await env.DB.prepare(
        "SELECT * FROM bookings WHERE series_id = ? AND practitioner_id = ? AND status = 'confirmed' AND start_utc >= ?"
      ).bind(seriesId, pid, nowMin()).all()).results) || [];
    }
    const one = await env.DB.prepare(
      "SELECT * FROM bookings WHERE id = ? AND practitioner_id = ? AND status = 'confirmed'"
    ).bind(bookingId, pid).first();
    return one ? [one] : [];
  }

  if (action === "remove-series") {
    const rows = await futureRows(b.series_id, b.booking_id);
    if (!rows.length) return json({ error: "Nothing to remove." }, 404);
    const stmts = rows.map((r) => env.DB
      .prepare("UPDATE bookings SET status = 'cancelled', cancelled_at = datetime('now'), updated_at = datetime('now') WHERE id = ?")
      .bind(r.id));
    for (let i = 0; i < stmts.length; i += 40) await env.DB.batch(stmts.slice(i, i + 40));
    return json({ ok: true, removed: rows.length });
  }

  if (action === "edit-series") {
    const rows = await futureRows(b.series_id, b.booking_id);
    if (!rows.length) return json({ error: "Nothing to edit." }, 404);

    const newWeekday = (b.weekday === 0 || b.weekday) ? parseInt(b.weekday, 10) : null; // 0..6 or null
    const newTime = /^\d{1,2}:\d{2}$/.test(b.time || "") ? b.time : null;
    const roomId = parseInt(b.room_id, 10) || null;
    const dur = b.duration_min ? Math.max(15, Math.min(settings.maxDuration, parseInt(b.duration_min, 10))) : null;
    const ct = b.client_type === "referred" ? "referred" : (b.client_type === "private" ? "private" : null);

    const stmts = [];
    let clashes = 0, updated = 0;
    for (const r of rows) {
      const wp = wallParts(r.start_utc, tz);
      let { y, m, d } = wp;
      if (newWeekday !== null) {
        const cw = utcDay(y, m, d);
        const delta = newWeekday - cw;             // stay within the same Mon-Sun week
        ({ y, m, d } = shiftDate(y, m, d, delta));
      }
      let hh = wp.hh, mm = wp.mm;
      if (newTime) { const [h, mi] = newTime.split(":").map((n) => parseInt(n, 10)); hh = h; mm = mi; }
      const rRoom = roomId || r.room_id;
      const rDur = dur || r.duration_min;
      const rCt = ct || r.client_type;
      const newStart = utcIso(wallToUTC(y, m, d, hh, mm, tz));

      if (newStart < nowMin()) { continue; } // don't move an occurrence into the past
      if (!(await isRoomFree(env, rRoom, newStart, rDur, r.id))) { clashes++; continue; }

      const rate = rateForBooking(settings, { clientType: rCt, durationMin: rDur });
      const kind = rate === settings.rateBlock ? "block" : "adhoc";
      stmts.push(env.DB.prepare(
        "UPDATE bookings SET room_id=?, start_utc=?, duration_min=?, client_type=?, rate_pence=?, kind=?, updated_at=datetime('now') WHERE id=?"
      ).bind(rRoom, newStart, rDur, rCt, rate, kind, r.id));
      updated++;
    }
    for (let i = 0; i < stmts.length; i += 40) await env.DB.batch(stmts.slice(i, i + 40));
    return json({ ok: true, updated, skipped: clashes });
  }

  if (action === "add-series") {
    const weekday = parseInt(b.weekday, 10);
    const time = /^\d{1,2}:\d{2}$/.test(b.time || "") ? b.time : null;
    const roomId = parseInt(b.room_id, 10);
    const dur = Math.max(15, Math.min(settings.maxDuration, parseInt(b.duration_min, 10) || 60));
    const ct = b.client_type === "referred" ? "referred" : "private";
    if (isNaN(weekday) || weekday < 0 || weekday > 6 || !time || !roomId) {
      return json({ error: "Pick a room, a day and a time." }, 400);
    }
    const room = await env.DB.prepare("SELECT id FROM rooms WHERE id = ? AND active = 1").bind(roomId).first();
    if (!room) return json({ error: "That room is unavailable." }, 400);

    const [hh, mm] = time.split(":").map((n) => parseInt(n, 10));
    // First occurrence: the next matching weekday from today (inclusive).
    const today = new Date();
    let y = today.getUTCFullYear(), m = today.getUTCMonth() + 1, d = today.getUTCDate();
    const cw = utcDay(y, m, d);
    ({ y, m, d } = shiftDate(y, m, d, (weekday - cw + 7) % 7));

    const rate = rateForBooking(settings, { clientType: ct, durationMin: dur });
    const kind = rate === settings.rateBlock ? "block" : "adhoc";
    const seriesId = crypto.randomUUID();

    const stmts = [];
    let clashes = 0, added = 0;
    for (let i = 0; i < HORIZON_WEEKS; i++) {
      const occ = shiftDate(y, m, d, i * 7);
      const start = utcIso(wallToUTC(occ.y, occ.m, occ.d, hh, mm, tz));
      if (start < nowMin()) continue;
      if (!(await isRoomFree(env, roomId, start, dur, null))) { clashes++; continue; }
      stmts.push(env.DB.prepare(
        "INSERT INTO bookings (room_id, practitioner_id, series_id, start_utc, duration_min, client_type, kind, rate_pence, status, note) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'confirmed', 'seed:golive-cal')"
      ).bind(roomId, pid, seriesId, start, dur, ct, kind, rate));
      added++;
    }
    if (!added) return json({ error: "Every week at that room and time is already booked.", skipped: clashes }, 409);
    for (let i = 0; i < stmts.length; i += 40) await env.DB.batch(stmts.slice(i, i + 40));
    return json({ ok: true, added, skipped: clashes });
  }

  return json({ error: "Unknown action" }, 400);
}
