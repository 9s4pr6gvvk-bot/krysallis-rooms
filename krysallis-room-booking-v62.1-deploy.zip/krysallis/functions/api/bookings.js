import { json } from "../../shared/http.js";
import { sendEmail, emailShell, emailTitle, emailDetails, emailNote, emailSpacer, esc } from "../../shared/email.js";
import { getSettings, isRoomFree, rateForBooking, buildOccurrences, localDate, formatSlot } from "../../shared/booking-logic.js";
import { pushBooking, getAccessToken } from "../../shared/gcal.js";

// GET  /api/bookings          -> admin: all upcoming; practitioner: own upcoming
// GET  /api/bookings?all=1    -> admin: everything incl. past
// POST /api/bookings          -> create a booking, optionally repeating
export async function onRequestGet(context) {
  const { env, data } = context;
  const url = new URL(context.request.url);
  const q = url.searchParams;
  const wantAll = q.get("all") === "1";
  const nowIso = new Date().toISOString().slice(0, 16);

  // Optional window (ignored when all=1). Keeps the admin list light instead of
  // returning every recurring session years out.
  //   days=N            now .. now + N days
  //   from=YYYY-MM-DD   lower bound (defaults to now)
  //   to=YYYY-MM-DD     upper bound
  const days = parseInt(q.get("days") || "", 10);
  const from = /^\d{4}-\d{2}-\d{2}$/.test(q.get("from") || "") ? q.get("from") : null;
  const to   = /^\d{4}-\d{2}-\d{2}$/.test(q.get("to")   || "") ? q.get("to")   : null;
  const limit  = Math.min(500, parseInt(q.get("limit")  || "", 10) || 0);
  const offset = Math.max(0,   parseInt(q.get("offset") || "", 10) || 0);

  let sql = `SELECT b.*, r.name AS room_name, p.name AS pract_name, p.email AS pract_email
             FROM bookings b JOIN rooms r ON r.id=b.room_id JOIN practitioners p ON p.id=b.practitioner_id`;
  const where = [], bind = [];
  if (!data.session.admin) { where.push("b.practitioner_id = ?"); bind.push(data.session.pid); }
  if (!wantAll) {
    where.push("b.status = 'confirmed'");
    where.push("b.start_utc >= ?"); bind.push(from ? from + "T00:00" : nowIso);
    if (Number.isFinite(days) && days > 0) {
      where.push("b.start_utc <= ?");
      bind.push(new Date(Date.now() + days * 86400000).toISOString().slice(0, 16));
    } else if (to) {
      where.push("b.start_utc <= ?"); bind.push(to + "T23:59");
    }
  }
  if (where.length) sql += " WHERE " + where.join(" AND ");
  sql += " ORDER BY b.start_utc ASC";
  if (limit > 0) { sql += " LIMIT ? OFFSET ?"; bind.push(limit, offset); }
  const { results } = await env.DB.prepare(sql).bind(...bind).all();
  return json(results || []);
}

export async function onRequestPost(context) {
  const { env, data } = context;
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const settings = await getSettings(env);
  const roomId = parseInt(b.room_id, 10);
  const start = (b.start_utc || "").toString().slice(0, 16);
  const duration = Math.max(15, Math.min(settings.maxDuration, parseInt(b.duration_min, 10) || 60));
  const note = (b.note || "").toString().trim().slice(0, 500);

  // Booking type is deliberately not defaulted. Dual therapists book both kinds
  // and the invoice depends on it, so the caller has to say which this is.
  if (b.client_type !== "private" && b.client_type !== "referred") {
    return json({ error: "Choose whether this is a private booking or a Krysallis booking." }, 400);
  }
  const clientType = b.client_type;

  // Admin can book on behalf of any practitioner by passing practitioner_id
  const practId = data.session.admin && b.practitioner_id
    ? parseInt(b.practitioner_id, 10)
    : data.session.pid;

  if (!roomId || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(start)) return json({ error: "Pick a room and a time." }, 400);

  const room = await env.DB.prepare("SELECT id, name FROM rooms WHERE id = ? AND active = 1").bind(roomId).first();
  if (!room) return json({ error: "That room is unavailable." }, 400);

  // The portal works out free times in the browser, so a device with a wrong
  // clock could offer a slot that has already gone. Admin can still record a
  // session that has already happened; practitioners cannot book into the past.
  if (!data.session.admin && new Date(start + "Z").getTime() < Date.now() - 60000) {
    return json({ error: "That time has already passed. Please pick a later time." }, 400);
  }

  // ── Repeat pattern ────────────────────────────────────────────────────────
  // repeat_every_weeks : 1 = every week, 2 = every two weeks
  // repeat_count       : total number of sessions
  // repeat_until       : YYYY-MM-DD, series ends on or before this date
  // repeat_weeks       : legacy field (extra sessions after the first)
  const intervalWeeks = Math.max(1, Math.min(4, parseInt(b.repeat_every_weeks, 10) || 1));
  const untilDate = /^\d{4}-\d{2}-\d{2}$/.test(b.repeat_until || "") ? b.repeat_until : null;
  let count = parseInt(b.repeat_count, 10) || 0;
  if (!count && b.repeat_weeks !== undefined) count = (parseInt(b.repeat_weeks, 10) || 0) + 1;
  if (!count) count = 1;

  const horizonEnd = localDate(
    new Date(Date.now() + settings.horizon * 86400000).toISOString().slice(0, 16),
    settings.timezone
  );
  if (untilDate && untilDate > horizonEnd) {
    return json({ error: `Repeat bookings can currently run up to ${horizonEnd}. Choose an earlier end date.` }, 400);
  }

  let occurrences = buildOccurrences(start, {
    intervalWeeks, count, untilDate, timeZone: settings.timezone,
  });
  if (!occurrences.length) return json({ error: "That repeat pattern produced no sessions." }, 400);

  // ── Clash check ───────────────────────────────────────────────────────────
  // Every occurrence is checked against the calendar before anything is saved.
  // If some dates are already taken we report exactly which, so the booker can
  // either pick another slot or keep the series and skip the clashing weeks.
  const clashes = [], free = [];
  for (const occ of occurrences) {
    if (await isRoomFree(env, roomId, occ, duration)) free.push(occ);
    else clashes.push({ start: occ, label: formatSlot(occ, settings.timezone) });
  }
  if (clashes.length) {
    if (!b.skip_clashes) {
      return json({
        error: occurrences.length === 1
          ? `${room.name} is already booked at ${clashes[0].label}. Nothing was saved.`
          : `${clashes.length} of the ${occurrences.length} sessions clash with an existing booking in ${room.name}. Nothing was saved.`,
        clashes, total: occurrences.length, bookable: free.length, room: room.name,
      }, 409);
    }
    if (!free.length) return json({ error: `Every session in that series is already booked in ${room.name}.`, clashes }, 409);
    occurrences = free;
  }

  const ratePence = rateForBooking(settings, { clientType, durationMin: duration });
  const seriesId = occurrences.length > 1 ? crypto.randomUUID() : null;
  const kind = ratePence === settings.rateBlock ? "block" : "adhoc";
  const practRecord = await env.DB.prepare("SELECT name FROM practitioners WHERE id = ?").bind(practId).first();
  const practName = practRecord ? practRecord.name : data.session.name;
  const gcalToken = await getAccessToken(env);
  const saved = [];
  for (const occ of occurrences) {
    const res = await env.DB.prepare(
      `INSERT INTO bookings (room_id, practitioner_id, series_id, start_utc, duration_min, client_type, kind, rate_pence, note)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING *`
    ).bind(roomId, practId, seriesId, occ, duration, clientType, kind, ratePence, note).all();
    const row = res.results[0];
    const eventId = await pushBooking(env, {
      summary: `${practName} - ${room.name}`,
      startUtc: occ, durationMin: duration, roomId, token: gcalToken,
    });
    if (eventId) {
      const calId = roomId === 1 ? env.GCAL_CAL_ROOM1 : roomId === 2 || roomId === 3 ? env.GCAL_CAL_ROOMS23 : env.GCAL_CAL_ROOM4;
      await env.DB.prepare("UPDATE bookings SET gcal_event_id = ? WHERE id = ?").bind(calId ? `${calId}|${eventId}` : eventId, row.id).run();
    }
    saved.push(row);
  }

  // Confirm to the practitioner + copy Paddy.
  const first = formatSlot(occurrences[0], settings.timezone);
  const last = formatSlot(occurrences[occurrences.length - 1], settings.timezone);
  const everyLabel = intervalWeeks === 2 ? "every 2 weeks" : "weekly";
  const skipLine = (b.skip_clashes && clashes.length)
    ? emailNote(`${clashes.length} date(s) in this pattern were already booked and have been skipped.`, { tone: "warn" }) + emailSpacer(14)
    : "";
  const typeLabel = clientType === "referred" ? "Krysallis booking (no room charge)" : "Private booking";
  const practitioner = practId !== data.session.pid
    ? await env.DB.prepare("SELECT name, email FROM practitioners WHERE id = ?").bind(practId).first()
    : { name: data.session.name, email: data.session.email };
  const practConfirmHtml = emailShell(
    emailTitle("Booking confirmed") +
    emailDetails([
      ["Room", esc(room.name)],
      ["Date &amp; time", esc(first)],
      ["Duration", `${duration} min`],
      ["Type", esc(typeLabel)],
      occurrences.length > 1 ? ["Repeats", `${everyLabel}, ${occurrences.length} sessions (last: ${esc(last)})`] : null,
    ]) +
    skipLine +
    emailNote(`Cancel at least ${settings.noticeHours} hours ahead to avoid a charge. Inside ${settings.noticeHours} hours, contact Krysallis directly.`),
    { preheader: `Your booking for ${room.name} on ${first} is confirmed.` }
  );
  await sendEmail(env, {
    to: practitioner.email,
    subject: `Room booked - ${room.name}, ${first}`,
    html: practConfirmHtml,
  });
  const adminTo = env.ADMIN_EMAIL;
  if (adminTo && adminTo.toLowerCase() !== (practitioner.email || "").toLowerCase()) {
    const adminHtml = emailShell(
      emailTitle("New booking") +
      emailDetails([
        ["Practitioner", esc(practitioner.name)],
        ["Room", esc(room.name)],
        ["Date &amp; time", esc(first)],
        ["Duration", `${duration} min`],
        ["Type", esc(typeLabel)],
        occurrences.length > 1 ? ["Repeats", `${everyLabel}, ${occurrences.length} sessions`] : null,
      ]),
      { preheader: `${practitioner.name} booked ${room.name} for ${first}.` }
    );
    await sendEmail(env, { to: adminTo, subject: `New room booking - ${practitioner.name}, ${room.name}`, html: adminHtml });
  }
  return json({
    ok: true, count: saved.length, first, last,
    skipped: b.skip_clashes ? clashes.length : 0,
    every_weeks: intervalWeeks,
  });
}
