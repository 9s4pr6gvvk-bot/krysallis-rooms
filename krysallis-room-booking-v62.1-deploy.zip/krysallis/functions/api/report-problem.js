import { json } from "../../shared/http.js";
import { sendEmail, emailShell, emailTitle, emailDetails, emailText, esc } from "../../shared/email.js";

// POST /api/report-problem  -> emails a problem report to Franks Media (support).
// Any authenticated user can send one. The reporter's name/email come from the
// session, so they can't be spoofed from the client.
export async function onRequestPost(context) {
  const { env, data } = context;
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const what = (b.what || "").toString().trim().slice(0, 300);
  const detail = (b.detail || "").toString().trim().slice(0, 2000);
  const page = (b.page || "").toString().trim().slice(0, 300);
  if (!detail) return json({ error: "Please describe the problem." }, 400);

  const reporterName = data.session?.name || "Unknown user";
  const reporterEmail = data.session?.email || "unknown";

  // Where reports go. Set REPORT_EMAIL as a secret/var on the project; falls
  // back to the Franks Media support inbox.
  const to = env.REPORT_EMAIL || "hello@franks-media.co.uk";

  const html = emailShell(
    emailTitle("Problem reported") +
    emailDetails([
      ["From", esc(reporterName)],
      ["Email", esc(reporterEmail)],
      what ? ["Trying to", esc(what)] : null,
      page ? ["Page", esc(page)] : null,
    ]) +
    emailText(`<strong>What happened</strong><br>${esc(detail).replace(/\n/g, "<br>")}`),
    { preheader: `Problem report from ${reporterName}` }
  );

  const res = await sendEmail(env, {
    to,
    subject: `Room booking problem report - ${reporterName}`,
    html,
    replyTo: reporterEmail !== "unknown" ? reporterEmail : undefined,
  });

  // sendEmail no-ops (skipped) until RESEND_API_KEY is set; treat that as success
  // so the UI works during testing.
  if (res && res.ok === false) return json({ error: "Could not send the report." }, 502);
  return json({ ok: true });
}
