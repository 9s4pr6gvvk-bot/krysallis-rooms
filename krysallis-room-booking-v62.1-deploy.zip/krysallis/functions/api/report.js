import { json } from "../../shared/http.js";
import { getSettings, wallToUTC, utcIso } from "../../shared/booking-logic.js";

// GET /api/report?month=YYYY-MM             -> admin: every practitioner's totals
// GET /api/report?month=YYYY-MM&format=csv  -> admin: CSV for invoicing
// Practitioners get their own figures only.
//
// Chargeable = confirmed + cancelled_late. Krysallis-referred sessions count as
// hours but carry no charge. Where a practitioner has a monthly agreement for
// the month, the agreed fee replaces the per-session charge for the hours it
// covers; anything beyond the included hours is billed on top at the ad hoc rate.
export async function onRequestGet(context) {
  const { env, data } = context;
  const url = new URL(context.request.url);
  const month = url.searchParams.get("month") || new Date().toISOString().slice(0, 7);
  if (!/^\d{4}-\d{2}$/.test(month)) return json({ error: "month must be YYYY-MM" }, 400);
  const settings = await getSettings(env);
  const tz = settings.timezone;

  // Month boundaries in local time, so a 00:30 booking on the 1st lands in the
  // right month rather than the previous one.
  const [yy, mm] = month.split("-").map(Number);
  const nextY = mm === 12 ? yy + 1 : yy, nextM = mm === 12 ? 1 : mm + 1;
  const lo = utcIso(wallToUTC(yy, mm, 1, 0, 0, tz));
  const hi = utcIso(new Date(wallToUTC(nextY, nextM, 1, 0, 0, tz).getTime() - 60000));

  let sql = `SELECT b.*, p.name AS pract_name, p.email AS pract_email, r.name AS room_name
             FROM bookings b JOIN practitioners p ON p.id=b.practitioner_id JOIN rooms r ON r.id=b.room_id
             WHERE b.status IN ('confirmed','cancelled_late') AND b.start_utc BETWEEN ? AND ?`;
  const bind = [lo, hi];
  if (!data.session.admin) { sql += " AND b.practitioner_id = ?"; bind.push(data.session.pid); }
  sql += " ORDER BY p.name, b.start_utc";
  const { results } = await env.DB.prepare(sql).bind(...bind).all();

  // Monthly agreements in force for this month.
  let agreements = [];
  try {
    const q = await env.DB.prepare(
      `SELECT a.*, p.name AS pract_name, p.email AS pract_email
       FROM monthly_agreements a JOIN practitioners p ON p.id = a.practitioner_id
       WHERE a.active = 1 AND a.starts_month <= ? AND (a.ends_month IS NULL OR a.ends_month >= ?)`
    ).bind(month, month).all();
    agreements = q.results || [];
  } catch { agreements = []; }
  if (!data.session.admin) agreements = agreements.filter((a) => a.practitioner_id === data.session.pid);
  const agreementFor = {};
  for (const a of agreements) agreementFor[a.pract_email] = a;

  const fmtLocal = (iso) => new Date(iso + "Z").toLocaleString("en-GB", {
    timeZone: tz, day: "2-digit", month: "short", year: "numeric",
    hour: "2-digit", minute: "2-digit", hour12: false,
  });

  // Aggregate per practitioner.
  const byPract = {};
  const blank = (name, email) => ({
    name, email, adhocHours: 0, blockHours: 0, referredHours: 0, lateHours: 0,
    privateHours: 0, sessionCharge: 0, lines: [],
  });
  for (const r of results || []) {
    const hrs = r.duration_min / 60;
    const charge = (r.rate_pence * hrs) / 100; // pounds
    const g = byPract[r.pract_email] || (byPract[r.pract_email] = blank(r.pract_name, r.pract_email));
    if (r.client_type === "referred") g.referredHours += hrs;
    else {
      g.privateHours += hrs;
      if (r.kind === "block") g.blockHours += hrs; else g.adhocHours += hrs;
    }
    if (r.status === "cancelled_late") g.lateHours += hrs;
    g.sessionCharge += charge;
    g.lines.push({
      date: r.start_utc, local: fmtLocal(r.start_utc), room: r.room_name, minutes: r.duration_min,
      client: r.client_type, kind: r.kind, status: r.status,
      rate: r.rate_pence / 100, charge: Math.round(charge * 100) / 100,
    });
  }
  // A practitioner on a monthly deal still appears even with no sessions logged.
  for (const a of agreements) if (!byPract[a.pract_email]) byPract[a.pract_email] = blank(a.pract_name, a.pract_email);

  const round = (n) => Math.round(n * 100) / 100;
  const summary = Object.values(byPract).map((g) => {
    const a = agreementFor[g.email];
    const out = {
      ...g,
      adhocHours: round(g.adhocHours), blockHours: round(g.blockHours),
      referredHours: round(g.referredHours), lateHours: round(g.lateHours),
      privateHours: round(g.privateHours), sessionCharge: round(g.sessionCharge),
    };
    if (a) {
      const fee = a.amount_pence / 100;
      // Monthly allowance. If the deal records its weekly hours and the weekday(s)
      // it runs, the allowance flexes to how many of those days fall in THIS month,
      // so a month with a 5th occurrence isn't billed as an overrun. Otherwise fall
      // back to the flat included_hours figure.
      let included = Number(a.included_hours) || 0;
      const perWeek = Number(a.included_per_week) || 0;
      if (perWeek > 0 && a.weekdays) {
        const days = String(a.weekdays).split(",").map((x) => Number(x.trim())).filter((n) => !Number.isNaN(n));
        if (days.length) {
          let occ = 0;
          const daysInMonth = new Date(yy, mm, 0).getDate();
          for (let d = 1; d <= daysInMonth; d++) {
            if (days.includes(new Date(Date.UTC(yy, mm - 1, d)).getUTCDay())) occ++;
          }
          included = round(perWeek * (occ / days.length));
        }
      }
      const extraHours = included > 0 ? Math.max(0, out.privateHours - included) : 0;
      const extraCharge = round(extraHours * (settings.rateAdhoc / 100));
      out.agreement = {
        fee: round(fee), includedHours: included, note: a.note || "",
        extraHours: round(extraHours), extraCharge,
        coversAll: included === 0,
      };
      out.charge = round(fee + extraCharge);
    } else {
      out.agreement = null;
      out.charge = out.sessionCharge;
    }
    return out;
  }).sort((x, y) => x.name.localeCompare(y.name));

  const grandTotal = round(summary.reduce((n, g) => n + g.charge, 0));

  if (url.searchParams.get("format") === "csv") {
    const rows = [];
    rows.push(["KRYSALLIS ROOM BOOKING", month]);
    rows.push([]);
    rows.push(["SUMMARY (one row per practitioner)"]);
    rows.push(["Practitioner", "Email", "Private hours", "Krysallis hours", "Ad hoc hours", "Block hours",
      "Late cancel hours", "Monthly agreement", "Included hours", "Hours over agreement",
      "Charge over agreement", "Per session charge", "Total due", "Agreement note"]);
    for (const g of summary) {
      const a = g.agreement;
      rows.push([
        g.name, g.email, g.privateHours, g.referredHours, g.adhocHours, g.blockHours, g.lateHours,
        a ? a.fee.toFixed(2) : "", a ? (a.coversAll ? "all" : a.includedHours) : "",
        a ? a.extraHours : "", a ? a.extraCharge.toFixed(2) : "",
        a ? "" : g.sessionCharge.toFixed(2), g.charge.toFixed(2), a ? a.note : "",
      ]);
    }
    rows.push([]);
    rows.push(["TOTAL DUE", grandTotal.toFixed(2)]);
    rows.push([]);
    rows.push(["DETAIL (one row per session)"]);
    rows.push(["Practitioner", "Email", "Date and time", "Room", "Minutes", "Booking type",
      "Session type", "Rate/hr", "Charge", "Status", "Covered by monthly agreement"]);
    for (const g of summary) for (const l of g.lines) {
      rows.push([
        g.name, g.email, l.local, l.room, l.minutes,
        l.client === "referred" ? "Krysallis (not charged)" : "Private (chargeable)",
        l.kind === "block" ? "Block" : "Ad hoc",
        l.rate.toFixed(2), l.charge.toFixed(2),
        l.status === "cancelled_late" ? "Late cancellation (charged)" : "Confirmed",
        g.agreement && l.client !== "referred" ? "Yes" : "",
      ]);
    }
    const csv = rows.map((r) => r.map((c) => `"${String(c == null ? "" : c).replace(/"/g, '""')}"`).join(",")).join("\n");
    return new Response(csv, {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="krysallis-${month}.csv"`,
      },
    });
  }
  return json({ month, currency: "GBP", rate_adhoc: settings.rateAdhoc / 100, total: grandTotal, summary });
}
