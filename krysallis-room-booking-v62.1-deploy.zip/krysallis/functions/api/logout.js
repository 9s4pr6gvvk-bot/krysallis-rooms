import { json } from "../../shared/http.js";
import { clearCookie } from "../../shared/auth.js";
export async function onRequestPost() {
  return json({ ok: true }, 200, { "Set-Cookie": clearCookie() });
}
