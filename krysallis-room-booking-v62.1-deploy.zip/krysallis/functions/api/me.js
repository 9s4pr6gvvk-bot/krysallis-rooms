import { json } from "../../shared/http.js";

// Returns the current session, plus `confirmed`: whether this practitioner has
// completed the one-time first-login booking check. Admins and the developer
// are always treated as confirmed. The lookup is guarded so that if the
// migration hasn't run yet (column missing) we default to confirmed = true and
// never block anyone at the login screen.
export async function onRequestGet(context) {
  const s = context.data.session;

  let confirmed = true;
  if (!s.admin && !s.developer) {
    try {
      const row = await context.env.DB
        .prepare("SELECT bookings_confirmed_at FROM practitioners WHERE id = ?")
        .bind(s.pid).first();
      confirmed = !!(row && row.bookings_confirmed_at);
    } catch {
      confirmed = true; // column not present yet -> no gate
    }
  }

  return json({ id: s.pid, name: s.name, email: s.email, admin: s.admin, developer: !!s.developer, confirmed });
}
