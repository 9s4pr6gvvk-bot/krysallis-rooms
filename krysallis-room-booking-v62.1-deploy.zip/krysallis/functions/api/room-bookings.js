import { json } from "../../shared/http.js";

// GET /api/room-bookings?room=ID&from=YYYY-MM-DD&to=YYYY-MM-DD
// Returns all confirmed bookings for a room in a date window, with practitioner
// first names, so the calendar can show who has each slot.
// Available to any authenticated user (practitioner or admin).
export async function onRequestGet(context) {
  const { env, data } = context;
  const url = new URL(context.request.url);
  const roomId = parseInt(url.searchParams.get("room"), 10);
  const from = url.searchParams.get("from") || "";
  const to = url.searchParams.get("to") || "";

  if (!roomId || !/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) {
    return json({ error: "room, from, and to required" }, 400);
  }

  // Widen the window slightly to catch UTC-shifted bookings near midnight.
  const { results } = await env.DB.prepare(
    `SELECT b.id, b.start_utc, b.duration_min, b.practitioner_id,
            p.name AS pract_name,
            (b.practitioner_id = ?) AS is_mine
     FROM bookings b
     JOIN practitioners p ON p.id = b.practitioner_id
     WHERE b.room_id = ?
       AND b.status = 'confirmed'
       AND date(b.start_utc) BETWEEN ? AND ?
     ORDER BY b.start_utc ASC`
  ).bind(data.session.pid, roomId, from, to).all();

  // Return first name only for other practitioners (privacy); full name for own.
  const bookings = (results || []).map((r) => ({
    id: r.id,
    start_utc: r.start_utc,
    duration_min: r.duration_min,
    is_mine: r.is_mine === 1,
    name: r.is_mine === 1
      ? r.pract_name
      : (r.pract_name || "").split(" ")[0],
  }));

  return json(bookings);
}
