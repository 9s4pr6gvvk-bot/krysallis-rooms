import { json } from "../../shared/http.js";
import { getSettings, utcIso } from "../../shared/booking-logic.js";

// GET /api/week?from=YYYY-MM-DD&days=7
// One payload for the whole calendar: every active room, every confirmed
// booking in the window, and the settings the grid needs. The portal works out
// free times from this locally, so switching room or session length costs
// nothing and the server is hit once per week instead of once per room per day.
//
// Practitioner names follow the same rule as /api/room-bookings: your own
// bookings come back with your full name, everyone else's with a first name.
export async function onRequestGet(context) {
  const { env, data } = context;
  const url = new URL(context.request.url);
  const from = url.searchParams.get("from") || "";
  const days = Math.min(31, Math.max(1, parseInt(url.searchParams.get("days"), 10) || 7));
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from)) return json({ error: "from required" }, 400);

  const settings = await getSettings(env);

  // A day either side of the window, so a session that starts late the night
  // before, or one stored a day ahead in UTC, is still returned.
  const start = new Date(from + "T00:00:00Z");
  const lo = isoDay(new Date(start.getTime() - 86400000));
  const hi = isoDay(new Date(start.getTime() + (days + 1) * 86400000));

  const roomRows = await env.DB.prepare(
    "SELECT id, name FROM rooms WHERE active = 1 ORDER BY sort_order, id"
  ).all();

  const { results } = await env.DB.prepare(
    `SELECT b.id, b.room_id, b.start_utc, b.duration_min, b.practitioner_id, p.name AS pract_name
     FROM bookings b
     JOIN practitioners p ON p.id = b.practitioner_id
     WHERE b.status = 'confirmed'
       AND date(b.start_utc) BETWEEN ? AND ?
     ORDER BY b.start_utc ASC`
  ).bind(lo, hi).all();

  const pid = data.session.pid;
  const bookings = (results || []).map((r) => {
    const mine = r.practitioner_id === pid;
    return {
      id: r.id,
      room_id: r.room_id,
      start_utc: r.start_utc,
      duration_min: r.duration_min,
      is_mine: mine,
      name: mine ? r.pract_name : (r.pract_name || "").split(" ")[0],
    };
  });

  return json({
    from,
    days,
    now_utc: utcIso(new Date()),
    timezone: settings.timezone,
    open_days: settings.days,
    open_start: settings.start,
    open_end: settings.end,
    step: settings.step,
    notice_hours: settings.noticeHours,
    rooms: roomRows.results || [],
    bookings,
  });
}

function isoDay(d) { return d.toISOString().slice(0, 10); }
