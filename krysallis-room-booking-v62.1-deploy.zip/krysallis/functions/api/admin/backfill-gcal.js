import { json } from "../../../shared/http.js";
import { getAccessToken, pushBooking } from "../../../shared/gcal.js";

// POST /api/admin/backfill-gcal
// One-off: push Leah's newly-added slots (migrate-v40-leah-newslots.sql) to
// Google Calendar, since they were inserted directly into D1 and so skipped
// the normal create-time calendar push.
//
// SCOPED TO LEAH ONLY, DELIBERATELY. Every other raw-SQL-seeded booking on
// this system (v27/v37/v39/v41/v42) was already manually on the room
// calendars before being imported into D1 — those must NEVER be swept up
// here, or every one of them gets a duplicate event created. That's why
// this queries by note='seed:golive-cal-v40' specifically, not by
// "gcal_event_id IS NULL" generally.
//
// Still waiting on Leah's confirmation — do not call without ?confirmed=1.
// Delete this file once the backfill has been run and confirmed.
export async function onRequestPost(context) {
  const { env, data, request } = context;
  if (!data.session.admin) return json({ error: "Admins only" }, 403);

  const confirmed = new URL(request.url).searchParams.get("confirmed") === "1";
  if (!confirmed) {
    return json({ ok: false, message: "Not run — call with ?confirmed=1 once Leah's slots are confirmed." });
  }

  const rows = (await env.DB.prepare(
    `SELECT b.id, b.room_id, b.start_utc, b.duration_min, p.name AS pract_name, r.name AS room_name
     FROM bookings b
     JOIN practitioners p ON p.id = b.practitioner_id
     JOIN rooms r ON r.id = b.room_id
     WHERE b.status = 'confirmed' AND b.gcal_event_id IS NULL AND b.note = 'seed:golive-cal-v40'
     ORDER BY b.start_utc`
  ).all()).results;

  if (!rows.length) return json({ ok: true, total: 0, synced: 0, failed: 0, message: "Nothing to backfill." });

  const token = await getAccessToken(env);
  if (!token) return json({ error: "Could not get a Google Calendar access token. Check the GCAL_* secrets are set." }, 500);

  let synced = 0, failed = 0;
  const failedIds = [];
  for (const row of rows) {
    const eventId = await pushBooking(env, {
      summary: `${row.pract_name} - ${row.room_name}`,
      startUtc: row.start_utc,
      durationMin: row.duration_min,
      roomId: row.room_id,
      token,
    });
    if (eventId) {
      const calId = row.room_id === 1 ? env.GCAL_CAL_ROOM1 : row.room_id === 2 || row.room_id === 3 ? env.GCAL_CAL_ROOMS23 : env.GCAL_CAL_ROOM4;
      await env.DB.prepare("UPDATE bookings SET gcal_event_id = ? WHERE id = ?")
        .bind(calId ? `${calId}|${eventId}` : eventId, row.id).run();
      synced++;
    } else {
      failed++;
      failedIds.push(row.id);
    }
  }

  return json({ ok: true, total: rows.length, synced, failed, failedIds });
}
