import { json } from "../../../shared/http.js";

// GET /api/admin/auth-log?email=&limit=
// Recent sign-in events, newest first. Admins only. Used by the "Sign-in log"
// tab in the admin console to trace a failed sign-in.
export async function onRequestGet(context) {
  const { env, data, request } = context;
  if (!data.session || !data.session.admin) return json({ error: "Admins only" }, 403);

  const url = new URL(request.url);
  const email = (url.searchParams.get("email") || "").trim().toLowerCase().slice(0, 200);
  let limit = parseInt(url.searchParams.get("limit") || "150", 10);
  if (!Number.isFinite(limit) || limit < 1) limit = 150;
  if (limit > 500) limit = 500;

  try {
    const q = email
      ? env.DB.prepare("SELECT ts, email, event, detail, ip, ua FROM auth_log WHERE email = ? ORDER BY id DESC LIMIT ?").bind(email, limit)
      : env.DB.prepare("SELECT ts, email, event, detail, ip, ua FROM auth_log ORDER BY id DESC LIMIT ?").bind(limit);
    const rows = (await q.all()).results || [];
    return json({ ok: true, rows });
  } catch {
    // Table not created yet (migration not run).
    return json({ ok: true, rows: [], note: "No log table yet. Run migrate-v60-signin-log.sql." });
  }
}
