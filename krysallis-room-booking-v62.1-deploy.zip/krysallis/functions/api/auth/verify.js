import { redirect } from "../../../shared/http.js";
import { logAuth } from "../../../shared/authlog.js";

// Sign-in links are retired. The system now emails a 6-digit code instead
// (see auth/request.js and auth/verify-code.js). This endpoint only stays so
// that an old link still sitting in someone's inbox, or opened by a mail
// scanner, lands them on the code sign-in page rather than a dead end. It never
// signs anyone in and never consumes anything.
async function handle(context) {
  const { request, env } = context;
  const token = new URL(request.url).searchParams.get("token") || "";
  let email = "";
  try {
    if (token) {
      const r = await env.DB.prepare("SELECT email FROM auth_tokens WHERE token = ?").bind(token).first();
      email = (r && r.email) || "";
    }
  } catch { /* ignore */ }
  await logAuth(env, { email, event: "old_link_opened", detail: "Old sign-in link opened; codes are used now", request });
  const base = env.SITE_URL || new URL(request.url).origin;
  return redirect(`${base}/portal/`);
}

export const onRequestGet = handle;
export const onRequestPost = handle;
