import { json, redirect } from "../../../shared/http.js";
import { createToken, sessionCookie } from "../../../shared/auth.js";

// GET /api/auth/impersonate?id=X  -> developer only
// Sets a session as the target practitioner so Franks Media can debug
// any account from both portal and admin without knowing their email.
export async function onRequestGet(context) {
  const { request, env, data } = context;
  const session = data.session;

  if (!session || !session.developer) {
    return json({ error: "Developer access only." }, 403);
  }

  const targetId = parseInt(new URL(request.url).searchParams.get("id") || "0", 10);
  if (!targetId) return json({ error: "Missing id." }, 400);

  const pract = await env.DB.prepare(
    "SELECT id, name, is_admin, is_developer, active FROM practitioners WHERE id = ?"
  ).bind(targetId).first();

  if (!pract || !pract.active) return json({ error: "Practitioner not found." }, 404);

  const dev = !!pract.is_developer;
  const sess = await createToken(env.SESSION_SECRET, { pid: pract.id, admin: !!pract.is_admin || dev, developer: dev });
  const base = env.SITE_URL || new URL(request.url).origin;
  const dest = (pract.is_admin || dev) ? `${base}/admin/` : `${base}/portal/`;
  return redirect(dest, { "Set-Cookie": sessionCookie(sess) });
}
