import { json } from "../../../shared/http.js";
import { createToken, sessionCookie } from "../../../shared/auth.js";
import { logAuth } from "../../../shared/authlog.js";

// POST /api/auth/verify-code { email, code } -> check the 6-digit code, and on a
// match set the session cookie and return where to go. The code is single use,
// expires in 10 minutes, and is locked out after 5 wrong tries.
export async function onRequestPost(context) {
  const { request, env } = context;
  let b; try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const email = (b.email || "").toString().trim().toLowerCase().slice(0, 200);
  const code = (b.code || "").toString().replace(/\D/g, "").slice(0, 6);

  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || code.length !== 6) {
    await logAuth(env, { email, event: "verify_code_fail", detail: "Missing or malformed email/code", request });
    return json({ error: "Enter the 6-digit code from your email." }, 400);
  }

  const row = await env.DB.prepare(
    "SELECT id, code, expires_at, used, attempts FROM auth_codes WHERE email = ? AND used = 0 ORDER BY id DESC LIMIT 1"
  ).bind(email).first();

  if (!row) {
    await logAuth(env, { email, event: "verify_code_fail", detail: "No active code (used, expired or never requested)", request });
    return json({ error: "That code is not valid. Please request a new one." }, 400);
  }
  if (new Date(row.expires_at) < new Date()) {
    await env.DB.prepare("UPDATE auth_codes SET used = 1 WHERE id = ?").bind(row.id).run();
    await logAuth(env, { email, event: "verify_code_fail", detail: "Code expired", request });
    return json({ error: "That code has expired. Please request a new one." }, 400);
  }
  if (row.attempts >= 5) {
    await env.DB.prepare("UPDATE auth_codes SET used = 1 WHERE id = ?").bind(row.id).run();
    await logAuth(env, { email, event: "verify_code_fail", detail: "Too many wrong attempts", request });
    return json({ error: "Too many attempts. Please request a new code." }, 429);
  }
  if (row.code !== code) {
    await env.DB.prepare("UPDATE auth_codes SET attempts = attempts + 1 WHERE id = ?").bind(row.id).run();
    await logAuth(env, { email, event: "verify_code_fail", detail: `Wrong code entered (attempt ${row.attempts + 1})`, request });
    return json({ error: "That code is not correct. Please check and try again." }, 400);
  }

  // Correct. Consume the code and sign in.
  await env.DB.prepare("UPDATE auth_codes SET used = 1 WHERE id = ?").bind(row.id).run();

  const pract = await env.DB.prepare(
    "SELECT id, is_admin, is_developer FROM practitioners WHERE lower(email) = ? AND active = 1"
  ).bind(email).first();
  if (!pract) {
    await logAuth(env, { email, event: "verify_code_fail", detail: "Email is not an active practitioner", request });
    return json({ error: "That code is not valid. Please request a new one." }, 400);
  }

  const dev = !!pract.is_developer;
  const sess = await createToken(env.SESSION_SECRET, { pid: pract.id, admin: !!pract.is_admin || dev, developer: dev });
  const dest = (pract.is_admin || dev) ? "/admin/" : "/portal/";
  await logAuth(env, { email, event: "verify_success", detail: `Signed in to ${(pract.is_admin || dev) ? "admin" : "portal"} (code)`, request });
  return json({ ok: true, dest }, 200, { "Set-Cookie": sessionCookie(sess) });
}
