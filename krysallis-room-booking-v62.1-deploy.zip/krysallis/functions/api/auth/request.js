import { json } from "../../../shared/http.js";
import { sendEmail, emailShell, emailTitle, emailText, emailCode, emailNote, esc } from "../../../shared/email.js";
import { logAuth } from "../../../shared/authlog.js";

// POST /api/auth/request { email, tsToken } -> if it matches an active
// practitioner, email them a 6-digit sign-in code. Always returns ok so the
// endpoint can't be used to discover who is registered.
//
// A typed code, not a link: mail privacy prefetchers and security scanners open
// links automatically (which was consuming the old one-time link before the
// person clicked). There is nothing to open here, so the code survives until
// the person enters it on the sign-in page.
export async function onRequestPost(context) {
  const { request, env } = context;
  let b; try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const email = (b.email || "").toString().trim().toLowerCase().slice(0, 200);
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    await logAuth(env, { email, event: "request_bad_email", detail: "Not a valid email address", request });
    return json({ error: "Please enter a valid email address." }, 400);
  }

  // Verify Turnstile token if secret is configured
  const tsSecret = env.TURNSTILE_SECRET;
  if (tsSecret) {
    const tsToken = (b.tsToken || "").toString().slice(0, 2048);
    if (!tsToken) return json({ error: "Security check required." }, 400);
    const ip = request.headers.get("CF-Connecting-IP") || "";
    const tsRes = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ secret: tsSecret, response: tsToken, remoteip: ip }),
    });
    const tsData = await tsRes.json();
    if (!tsData.success) {
      await logAuth(env, { email, event: "request_turnstile_fail", detail: "Turnstile security check failed", request });
      return json({ error: "Security check failed. Please try again." }, 403);
    }
  }

  const pract = await env.DB.prepare(
    "SELECT id, name FROM practitioners WHERE lower(email) = ? AND active = 1"
  ).bind(email).first();

  if (pract) {
    // One live code per email: retire any earlier unused ones first.
    await env.DB.prepare("UPDATE auth_codes SET used = 1 WHERE email = ? AND used = 0").bind(email).run();

    const code = String(crypto.getRandomValues(new Uint32Array(1))[0] % 1000000).padStart(6, "0");
    const expires = new Date(Date.now() + 10 * 60000).toISOString(); // 10 min
    await env.DB.prepare("INSERT INTO auth_codes (email, code, expires_at) VALUES (?, ?, ?)")
      .bind(email, code, expires).run();

    await sendEmail(env, {
      to: email,
      subject: `Your Krysallis sign-in code is ${code}`,
      html: emailShell(
        emailTitle(`Hi ${esc(pract.name)},`) +
        emailText("Here is your code to sign in to the Krysallis room booking system. Enter it on the sign-in page. It works once and expires in 10 minutes.") +
        emailCode(code) +
        emailNote("If you did not ask to sign in, you can ignore this email and no one will get access."),
        { preheader: `Your sign-in code is ${code}` }
      ),
    });
    await logAuth(env, { email, event: "request_sent", detail: `Sign-in code emailed to ${pract.name}`, request });
  } else {
    await logAuth(env, { email, event: "request_no_match", detail: "No active practitioner with this email", request });
  }
  return json({ ok: true });
}
