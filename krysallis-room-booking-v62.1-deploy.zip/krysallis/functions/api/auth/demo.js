import { json } from "../../../shared/http.js";
import { createToken, sessionCookie } from "../../../shared/auth.js";

// TEMPORARY demo login: one shared password, no email needed, so the system can
// be shown to the client before Resend is wired up. Any registered, active
// practitioner signs in with their email + the shared password. The real
// magic-link flow (auth/request + auth/verify) is untouched; switch the portal
// back to it once email is live, and remove/disable this route.
//
// Password is env.DEMO_PASSWORD if set, otherwise the built-in default below.
export async function onRequestPost(context) {
  const { request, env } = context;
  let b; try { b = await request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const email = (b.email || "").toString().trim().toLowerCase().slice(0, 200);
  const password = (b.password || "").toString();

  const DEMO = env.DEMO_PASSWORD || "Huddersfield";
  if (password !== DEMO) return json({ error: "Wrong password." }, 401);

  const pract = await env.DB.prepare(
    "SELECT id, is_admin, is_developer FROM practitioners WHERE lower(email) = ? AND active = 1"
  ).bind(email).first();
  if (!pract) return json({ error: "No practitioner found with that email." }, 404);

  const dev = !!pract.is_developer;
  const sess = await createToken(env.SESSION_SECRET, { pid: pract.id, admin: !!pract.is_admin || dev, developer: dev });
  return json({ ok: true, admin: !!pract.is_admin || dev, developer: dev }, 200, { "Set-Cookie": sessionCookie(sess) });
}
