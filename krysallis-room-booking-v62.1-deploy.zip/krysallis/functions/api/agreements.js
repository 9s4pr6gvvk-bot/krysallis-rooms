import { json } from "../../shared/http.js";

// Monthly agreements: the fixed monthly deals some therapists pay instead of
// being billed session by session. Admin only.
//   GET    /api/agreements              -> all, newest first
//   POST   /api/agreements              -> { practitioner_id, amount_pence, included_hours, starts_month, ends_month, note }
//   PATCH  /api/agreements              -> { id, ...same fields }
//   DELETE /api/agreements              -> { id }   (soft: active = 0)
function clean(b) {
  const amount = Math.max(0, Math.round(Number(b.amount_pence) || 0));
  const included = Math.max(0, Number(b.included_hours) || 0);
  const starts = /^\d{4}-\d{2}$/.test(b.starts_month || "") ? b.starts_month : null;
  const ends = /^\d{4}-\d{2}$/.test(b.ends_month || "") ? b.ends_month : null;
  const note = (b.note || "").toString().trim().slice(0, 200);
  return { amount, included, starts, ends, note };
}

export async function onRequestGet(context) {
  if (!context.data.session.admin) return json({ error: "Admins only" }, 403);
  const { results } = await context.env.DB.prepare(
    `SELECT a.*, p.name AS pract_name, p.email AS pract_email
     FROM monthly_agreements a JOIN practitioners p ON p.id = a.practitioner_id
     WHERE a.active = 1 ORDER BY p.name, a.starts_month DESC`
  ).all();
  return json(results || []);
}

export async function onRequestPost(context) {
  if (!context.data.session.admin) return json({ error: "Admins only" }, 403);
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const practId = parseInt(b.practitioner_id, 10);
  const { amount, included, starts, ends, note } = clean(b);
  if (!practId) return json({ error: "Choose a practitioner." }, 400);
  if (!starts) return json({ error: "Start month must be YYYY-MM." }, 400);
  if (ends && ends < starts) return json({ error: "The end month cannot be before the start month." }, 400);
  const res = await context.env.DB.prepare(
    `INSERT INTO monthly_agreements (practitioner_id, amount_pence, included_hours, note, starts_month, ends_month)
     VALUES (?, ?, ?, ?, ?, ?) RETURNING *`
  ).bind(practId, amount, included, note, starts, ends).all();
  return json(res.results[0]);
}

export async function onRequestPatch(context) {
  if (!context.data.session.admin) return json({ error: "Admins only" }, 403);
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const id = parseInt(b.id, 10);
  if (!id) return json({ error: "id required" }, 400);
  const { amount, included, starts, ends, note } = clean(b);
  if (!starts) return json({ error: "Start month must be YYYY-MM." }, 400);
  if (ends && ends < starts) return json({ error: "The end month cannot be before the start month." }, 400);
  await context.env.DB.prepare(
    "UPDATE monthly_agreements SET amount_pence=?, included_hours=?, note=?, starts_month=?, ends_month=? WHERE id=?"
  ).bind(amount, included, note, starts, ends, id).run();
  return json({ ok: true });
}

export async function onRequestDelete(context) {
  if (!context.data.session.admin) return json({ error: "Admins only" }, 403);
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const id = parseInt(b.id, 10);
  if (!id) return json({ error: "id required" }, 400);
  await context.env.DB.prepare("UPDATE monthly_agreements SET active = 0 WHERE id = ?").bind(id).run();
  return json({ ok: true });
}
