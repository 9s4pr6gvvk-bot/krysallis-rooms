import { json } from "../../../shared/http.js";
import { getSettings, isRoomFree, rateForBooking, hoursUntil, formatSlot } from "../../../shared/booking-logic.js";
import { removeBooking, updateBooking } from "../../../shared/gcal.js";
import { sendEmail, emailShell, emailTitle, emailDetails, emailNote, esc } from "../../../shared/email.js";

// PATCH /api/bookings/:id  -> cancel, or (admin) edit/move a booking.
//   { action:'cancel', scope:'one'|'series' }
//   { action:'cancel', scope:'one', charge:true }   (admin: keep the charge)
//   { action:'edit', room_id, start_utc, duration_min, client_type }  (admin)
export async function onRequestPatch(context) {
  const { env, data, params } = context;
  const id = parseInt(params.id, 10);
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }

  const bk = await env.DB.prepare("SELECT * FROM bookings WHERE id = ?").bind(id).first();
  if (!bk) return json({ error: "Not found" }, 404);
  const owns = bk.practitioner_id === data.session.pid;
  if (!owns && !data.session.admin) return json({ error: "Not allowed" }, 403);

  const settings = await getSettings(env);
  const isAdmin = !!data.session.admin;

  if (b.action === "cancel") {
    const targets = b.scope === "series" && bk.series_id
      ? (await env.DB.prepare("SELECT * FROM bookings WHERE series_id = ? AND status = 'confirmed' AND start_utc >= ?")
          .bind(bk.series_id, new Date().toISOString().slice(0, 16)).all()).results
      : [bk];

    // Email the practitioner (and copy admin) once we know what came off the
    // calendar. Mirrors the booking-confirmation emails. No-ops safely when
    // RESEND_API_KEY is not set, and never blocks the cancellation itself.
    async function notifyCancelled(slots, { charged }) {
      if (!slots.length) return;
      try {
        const pract = await env.DB.prepare("SELECT name, email FROM practitioners WHERE id = ?").bind(bk.practitioner_id).first();
        const room = await env.DB.prepare("SELECT name FROM rooms WHERE id = ?").bind(bk.room_id).first();
        const roomName = room ? room.name : "Room";
        const practName = pract ? pract.name : "Practitioner";
        const sorted = slots.slice().sort((x, y) => (x.start_utc < y.start_utc ? -1 : 1));
        const first = formatSlot(sorted[0].start_utc, settings.timezone);
        const many = sorted.length > 1;
        const listHtml = many
          ? emailNote(`Cancelled sessions:<br>${sorted.map((s) => `&bull; ${esc(formatSlot(s.start_utc, settings.timezone))}`).join("<br>")}`)
          : "";
        const chargeLine = charged
          ? emailNote(`This was inside the ${settings.noticeHours} hour notice window, so the room fee still applies.`, { tone: "warn" })
          : emailNote("No room charge applies.");
        if (pract && pract.email) {
          const practHtml = emailShell(
            emailTitle("Booking cancelled") +
            emailDetails([
              ["Room", esc(roomName)],
              [many ? "First session" : "Date &amp; time", esc(first)],
              many ? ["Sessions", `${sorted.length} cancelled`] : null,
            ]) +
            listHtml + chargeLine,
            { preheader: `Your booking for ${roomName} on ${first} has been cancelled.` }
          );
          await sendEmail(env, { to: pract.email, subject: `Booking cancelled - ${roomName}, ${first}`, html: practHtml });
        }
        const adminTo = env.ADMIN_EMAIL;
        if (adminTo && adminTo.toLowerCase() !== ((pract && pract.email) || "").toLowerCase()) {
          const adminHtml = emailShell(
            emailTitle("Booking cancelled") +
            emailDetails([
              ["Practitioner", esc(practName)],
              ["Room", esc(roomName)],
              [many ? "First session" : "Date &amp; time", esc(first)],
              many ? ["Sessions", `${sorted.length} cancelled`] : null,
              ["Charge", charged ? "Still chargeable" : "Free of charge"],
            ]) +
            listHtml,
            { preheader: `${practName} cancelled ${roomName} on ${first}.` }
          );
          await sendEmail(env, { to: adminTo, subject: `Cancelled - ${practName}, ${roomName}`, html: adminHtml });
        }
      } catch (e) { console.log("[email] cancel notify failed", e && e.message); }
    }

    // Practitioners cannot remove a session inside the notice window. It stays
    // on the calendar and Krysallis admin decides what happens to it.
    if (!isAdmin) {
      const locked = targets.filter((t) => t.status === "confirmed" && hoursUntil(t.start_utc) < settings.noticeHours);
      const cancellable = targets.filter((t) => t.status === "confirmed" && hoursUntil(t.start_utc) >= settings.noticeHours);
      if (!cancellable.length) {
        return json({
          error: `This session starts within ${settings.noticeHours} hours, so it can no longer be cancelled here and remains chargeable. Contact Krysallis if there are extenuating circumstances.`,
          locked: locked.length,
        }, 403);
      }
      let ok = 0;
      for (const t of cancellable) {
        await env.DB.prepare("UPDATE bookings SET status = 'cancelled', cancelled_at = datetime('now'), updated_at = datetime('now') WHERE id = ?").bind(t.id).run();
        if (t.gcal_event_id) await removeBooking(env, t.gcal_event_id);
        ok++;
      }
      await notifyCancelled(cancellable, { charged: false });
      return json({
        ok: true, cancelled: ok, locked: locked.length,
        message: locked.length
          ? `Cancelled ${ok} session(s). ${locked.length} session(s) start within ${settings.noticeHours} hours and stay on the calendar. Contact Krysallis to change those.`
          : (b.scope === "series" ? "Series cancelled." : "Cancelled."),
      });
    }

    // Admin: free of charge by default, or keep the charge with { charge: true }.
    const keepCharge = !!b.charge;
    let ok = 0;
    const cancelledSlots = [];
    for (const t of targets) {
      if (t.status !== "confirmed") continue;
      const newStatus = keepCharge && t.client_type !== "referred" ? "cancelled_late" : "cancelled";
      await env.DB.prepare("UPDATE bookings SET status = ?, cancelled_at = datetime('now'), updated_at = datetime('now') WHERE id = ?")
        .bind(newStatus, t.id).run();
      if (t.gcal_event_id) await removeBooking(env, t.gcal_event_id);
      cancelledSlots.push(t);
      ok++;
    }
    await notifyCancelled(cancelledSlots, { charged: keepCharge });
    return json({
      ok: true, cancelled: ok, charged: keepCharge ? ok : 0,
      message: keepCharge ? `Cancelled ${ok} session(s), still chargeable.` : `Cancelled ${ok} session(s) free of charge.`,
    });
  }

  if (b.action === "edit") {
    if (!isAdmin) return json({ error: "Admins only" }, 403);
    const roomId = parseInt(b.room_id, 10) || bk.room_id;
    const start = (b.start_utc || bk.start_utc).toString().slice(0, 16);
    const duration = Math.max(15, Math.min(settings.maxDuration, parseInt(b.duration_min, 10) || bk.duration_min));
    const clientType = b.client_type === "referred" ? "referred" : (b.client_type === "private" ? "private" : bk.client_type);
    if (!(await isRoomFree(env, roomId, start, duration, id)))
      return json({ error: `That room and time clashes with another booking (${formatSlot(start, settings.timezone)}).` }, 409);
    const ratePence = rateForBooking(settings, { clientType, durationMin: duration });
    const kind = ratePence === settings.rateBlock ? "block" : "adhoc";
    const practId = parseInt(b.practitioner_id, 10) || bk.practitioner_id;
    await env.DB.prepare("UPDATE bookings SET room_id=?, practitioner_id=?, start_utc=?, duration_min=?, client_type=?, rate_pence=?, kind=?, updated_at=datetime('now') WHERE id=?")
      .bind(roomId, practId, start, duration, clientType, ratePence, kind, id).run();

    // Keep Google Calendar in step with the edit — but only when this
    // booking already has a calendar event to update. Historical bookings
    // (v27/v37/v39/v41/v42, and Leah's v40 seed) were added directly to D1
    // and have no gcal_event_id, but most of them are already manually on
    // the room calendars. We cannot tell which, so never auto-create an
    // event here — that would risk a duplicate. If a booking with no
    // gcal_event_id is edited, its calendar entry (if any) must be updated
    // by hand; flag that back to the admin instead of guessing.
    let calendarSynced = true;
    if (bk.gcal_event_id) {
      const room = await env.DB.prepare("SELECT name FROM rooms WHERE id = ?").bind(roomId).first();
      const pract = await env.DB.prepare("SELECT name FROM practitioners WHERE id = ?").bind(practId).first();
      const summary = `${pract ? pract.name : "Practitioner"} - ${room ? room.name : "Room"}`;
      const newStoredId = await updateBooking(env, {
        storedId: bk.gcal_event_id, summary, startUtc: start, durationMin: duration, roomId,
      });
      if (newStoredId && newStoredId !== bk.gcal_event_id) {
        await env.DB.prepare("UPDATE bookings SET gcal_event_id = ? WHERE id = ?").bind(newStoredId, id).run();
      }
      calendarSynced = !!newStoredId;
    } else {
      calendarSynced = false;
    }

    return json({
      ok: true,
      ...(calendarSynced ? {} : { warning: "This booking has no linked Google Calendar event, so nothing was updated there automatically. If it's already on the calendar, update it by hand." }),
    });
  }
  return json({ error: "Unknown action" }, 400);
}
