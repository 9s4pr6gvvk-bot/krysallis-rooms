import { json } from "../../shared/http.js";
import { getSettings, roomDayAvailability } from "../../shared/booking-logic.js";

// GET /api/availability?room=ID&date=YYYY-MM-DD&duration=MIN
// -> free start times for that room, that day, that length.
export async function onRequestGet(context) {
  const { env } = context;
  const url = new URL(context.request.url);
  const roomId = parseInt(url.searchParams.get("room"), 10);
  const date = url.searchParams.get("date") || "";
  const duration = Math.max(15, parseInt(url.searchParams.get("duration"), 10) || 60);
  if (!roomId || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return json({ error: "room and date required" }, 400);

  const settings = await getSettings(env);
  const slots = await roomDayAvailability(env, settings, roomId, date, duration);
  return json({ date, duration, timezone: settings.timezone, open_start: settings.start, open_end: settings.end, slots });
}
