import { json } from "../../shared/http.js";

// GET    /api/practitioners        -> admin: list (active first, then blocked)
// POST   /api/practitioners        -> admin: add   { name, email, is_admin }
// PATCH  /api/practitioners        -> admin: edit  { id, name, email, is_admin }
//                                     or block/restore access { id, active: 0|1 }
// DELETE /api/practitioners        -> admin: remove { id }
//
// Blocking is the everyday control: it takes effect on the next request, keeps
// the person's booking history intact for reporting, and can be undone.
// Removing is permanent-ish and is refused while they still hold future rooms.
export async function onRequestGet(context) {
  if (!context.data.session.admin) return json({ error: "Admins only" }, 403);
  const { results } = await context.env.DB.prepare(
    `SELECT p.id, p.name, p.email, p.is_admin, p.is_developer, p.active,
            (SELECT COUNT(*) FROM bookings b
              WHERE b.practitioner_id = p.id AND b.status = 'confirmed'
                AND b.start_utc >= ?) AS upcoming
     FROM practitioners p ORDER BY p.active DESC, p.name`
  ).bind(new Date().toISOString().slice(0, 16)).all();
  return json(results || []);
}
export async function onRequestPost(context) {
  if (!context.data.session.admin) return json({ error: "Admins only" }, 403);
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const name = (b.name || "").toString().trim().slice(0, 120);
  const email = (b.email || "").toString().trim().toLowerCase().slice(0, 200);
  const isAdmin = b.is_admin ? 1 : 0;
  if (!name || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({ error: "Name and valid email required" }, 400);

  // If this email belongs to a previously-removed (inactive) practitioner,
  // reactivate and update that record rather than failing on the unique email.
  const existing = await context.env.DB.prepare(
    "SELECT id, active FROM practitioners WHERE email = ?"
  ).bind(email).first();
  if (existing) {
    if (existing.active === 1) return json({ error: "That email is already registered." }, 409);
    const res = await context.env.DB.prepare(
      "UPDATE practitioners SET name = ?, is_admin = ?, active = 1 WHERE id = ? RETURNING id, name, email, is_admin, active"
    ).bind(name, isAdmin, existing.id).all();
    return json(res.results[0]);
  }

  try {
    const res = await context.env.DB.prepare(
      "INSERT INTO practitioners (name, email, is_admin) VALUES (?, ?, ?) RETURNING id, name, email, is_admin, active"
    ).bind(name, email, isAdmin).all();
    return json(res.results[0]);
  } catch { return json({ error: "That email is already registered." }, 409); }
}
export async function onRequestPatch(context) {
  if (!context.data.session.admin) return json({ error: "Admins only" }, 403);
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const id = parseInt(b.id, 10);
  if (!id) return json({ error: "id required" }, 400);

  // Block or restore access without touching the rest of the record.
  if (b.active !== undefined && b.name === undefined) {
    const active = b.active ? 1 : 0;
    if (!active && id === context.data.session.pid) return json({ error: "You cannot block your own account." }, 409);
    await context.env.DB.prepare("UPDATE practitioners SET active = ? WHERE id = ?").bind(active, id).run();
    return json({ ok: true, active });
  }

  const name = (b.name || "").toString().trim().slice(0, 120);
  const email = (b.email || "").toString().trim().toLowerCase().slice(0, 200);
  const isAdmin = b.is_admin ? 1 : 0;
  if (!name || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({ error: "Name and valid email required" }, 400);
  try {
    await context.env.DB.prepare(
      "UPDATE practitioners SET name = ?, email = ?, is_admin = ? WHERE id = ?"
    ).bind(name, email, isAdmin, id).run();
    return json({ ok: true });
  } catch { return json({ error: "That email is already in use." }, 409); }
}
export async function onRequestDelete(context) {
  if (!context.data.session.admin) return json({ error: "Admins only" }, 403);
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const id = parseInt(b.id, 10);
  if (!id) return json({ error: "id required" }, 400);
  // Prevent removing yourself
  if (id === context.data.session.pid) return json({ error: "You cannot remove your own account." }, 409);
  // Check for upcoming bookings
  const bookings = await context.env.DB.prepare(
    "SELECT COUNT(*) as n FROM bookings WHERE practitioner_id = ? AND status = 'confirmed' AND start_utc >= datetime('now')"
  ).bind(id).first();
  if (bookings.n > 0) return json({ error: "This practitioner has upcoming bookings. Cancel them before removing." }, 409);
  await context.env.DB.prepare("UPDATE practitioners SET active = 0 WHERE id = ?").bind(id).run();
  return json({ ok: true });
}
