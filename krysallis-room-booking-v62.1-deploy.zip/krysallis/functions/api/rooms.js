import { json } from "../../shared/http.js";

// GET  /api/rooms  -> active rooms (all users)
// POST /api/rooms  -> admin: add a room  { name }
// PATCH /api/rooms -> admin: rename { id, name } | reorder { order: [id,id,...] } | delete { id, delete: true }
export async function onRequestGet(context) {
  const { results } = await context.env.DB.prepare(
    "SELECT id, name, sort_order, active FROM rooms WHERE active = 1 ORDER BY sort_order, id"
  ).all();
  return json(results || []);
}
export async function onRequestPost(context) {
  if (!context.data.session.admin) return json({ error: "Admins only" }, 403);
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }
  const name = (b.name || "").toString().trim().slice(0, 80);
  if (!name) return json({ error: "Room name required" }, 400);
  const res = await context.env.DB.prepare(
    "INSERT INTO rooms (name, sort_order) VALUES (?, (SELECT COALESCE(MAX(sort_order),0)+1 FROM rooms)) RETURNING *"
  ).bind(name).all();
  return json(res.results[0]);
}
export async function onRequestPatch(context) {
  if (!context.data.session.admin) return json({ error: "Admins only" }, 403);
  let b; try { b = await context.request.json(); } catch { return json({ error: "Bad request" }, 400); }
  // Reorder: { order: [id, id, ...] }
  if (Array.isArray(b.order)) {
    for (let i = 0; i < b.order.length; i++) {
      await context.env.DB.prepare("UPDATE rooms SET sort_order = ? WHERE id = ?").bind(i + 1, b.order[i]).run();
    }
    return json({ ok: true });
  }
  const id = parseInt(b.id, 10);
  if (!id) return json({ error: "id required" }, 400);
  // Soft delete: { id, delete: true }
  if (b.delete) {
    const bookings = await context.env.DB.prepare(
      "SELECT COUNT(*) as n FROM bookings WHERE room_id = ? AND status = 'confirmed' AND start_utc >= datetime('now')"
    ).bind(id).first();
    if (bookings.n > 0) return json({ error: "This room has upcoming bookings. Cancel them before removing the room." }, 409);
    await context.env.DB.prepare("UPDATE rooms SET active = 0 WHERE id = ?").bind(id).run();
    return json({ ok: true });
  }
  // Rename: { id, name }
  const name = (b.name || "").toString().trim().slice(0, 80);
  if (!name) return json({ error: "Room name required" }, 400);
  await context.env.DB.prepare("UPDATE rooms SET name = ? WHERE id = ?").bind(name, id).run();
  return json({ ok: true });
}
