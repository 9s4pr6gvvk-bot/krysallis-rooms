import { getSession, getAccessEmail } from "../shared/auth.js";
import { json } from "../shared/http.js";

// Unlike the public WC site, this is a members-only app: every /api route needs
// a valid practitioner session EXCEPT the login endpoints. Admin-only checks
// happen inside the individual handlers via context.data.session.admin.
export async function onRequest(context) {
  const { request } = context;
  const url = new URL(request.url);

  const session = await getSession(context);
  context.data.session = session;

  const isApi = url.pathname.startsWith("/api/");
  const isAuth = url.pathname === "/api/auth/request" || url.pathname === "/api/auth/verify" || url.pathname === "/api/auth/verify-code" || url.pathname === "/api/auth/demo";

  if (isApi && !isAuth && !session) {
    // If Cloudflare Access authenticated someone whose email is not a
    // practitioner, tell the client so it can show a useful message rather than
    // a login form.
    const accessEmail = await getAccessEmail(context);
    return json({ error: "Not authenticated", accessEmail: accessEmail || null }, 401);
  }
  return context.next();
}
