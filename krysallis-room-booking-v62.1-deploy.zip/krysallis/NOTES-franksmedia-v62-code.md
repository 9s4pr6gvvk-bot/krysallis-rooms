# Krysallis room booking - v62 deploy notes (Franks Media)

Sign-in is a 6-digit code the therapist types on the Krysallis sign-in page, in
place of the old email link. Fully on your own domain and branding. No link in
the email, so mail privacy prefetch and scanners have nothing to consume.

## v62.1 follow-up (this build)

Two fixes after the first v62 deploy, both about clearing up confusion in the
sign-in log:

- The old sign-in-link endpoint is retired. Any old link still in someone's
  inbox (or opened by Apple Mail privacy prefetch) now just lands them on the
  code sign-in page instead of the old confirm page. It signs no one in and
  consumes nothing. In the log this shows as "Old link opened".
- The sign-in log labels were still saying "Link sent" and "Link opened" from
  the old version. They now read "Code sent" and "Old link opened", so the log
  matches what the system actually does.

If you see "Old link opened" for a therapist, it means they opened a pre-switch
email. Tell them to use the newest email (subject starts "Your Krysallis sign-in
code is ...") or just request a fresh code.

## How sign-in works

1. Therapist opens krysallisroombooking.co.uk/portal.
2. Enters email, passes the security check, presses "Send my code".
3. We email a 6-digit code (the subject line shows it too).
4. They type the code on the same page and are signed in.

- Code is single use, expires in 10 minutes, locks after 5 wrong tries.
- Only the latest code for an email is valid.
- Sessions last 14 days per device.
- Admin/therapist split, first-login booking check, everything else unchanged.

## Deploy steps

1. Migration already run for the codes table (migrate-v62-signin-codes.sql). No
   new migration for v62.1.
2. Deploy the code as usual.

## Test after deploy

1. /portal, enter email, "Send my code", type the code, land in the portal
   (admins land in the admin console).
2. Admin console -> Sign-in log shows "Code sent" then "Signed in".

## Still in the project, dormant

- The Cloudflare Access code (shared/access.js and the Access branch in
  shared/auth.js) is present but inert: it does nothing unless the ACCESS_*
  variables are set, which they are not. It can be stripped out for tidiness
  whenever you want.
